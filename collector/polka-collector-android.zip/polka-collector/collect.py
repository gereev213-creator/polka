#!/usr/bin/env python3
"""Сборщик находок для «Полки».

Запускается У ВАС НА КОМПЬЮТЕРЕ, а не на сервере Amvera. Причина простая:
Авито блокирует адреса дата-центров, и при блокировке лёг бы весь сервис —
вместе с ботом, подписками и приложением. С домашнего IP запросы выглядят
как обычные.

Что делает:
  1. Открывает страницы поиска, которые вы указали в config.json.
  2. Достаёт из них карточки: заголовок, цену, город, ссылку, фото.
  3. Отправляет пачкой на сервер: POST /api/ingest с вашим токеном.

Чего НЕ делает:
  • не сохраняет имена и телефоны продавцов — только то, что видно в поиске;
  • не обходит капчу: увидел блокировку — останавливается и говорит об этом;
  • не долбит сайт: пауза между запросами 2–4 секунды плюс случайный разброс.

Запуск:
    python3 collect.py --selftest          # проверка разбора на образце
    python3 collect.py                     # один проход по всем запросам
    python3 collect.py --loop --every 900  # повторять каждые 15 минут
"""
import argparse
import base64
import glob
import json
import os
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import quote_plus
from html import unescape
from html.parser import HTMLParser

# Искать у Авито по тексту запроса (q=)?
#
# По умолчанию ВЫКЛЮЧЕНО — проверено на живом сайте 15.10.2026: обычный
# раздел Авито отдаёт (48 карточек), а ссылки с текстом запроса, подкатегорией
# или моделью в пути Авито отбивает кодами 429/439, причём сразу первым же
# запросом, а не из-за количества. Домашний IP не помогает: проверено и с него.
# Включённый по умолчанию q= означал бы, что сбор перестанет работать совсем.
#
# Включить: POLKA_SEARCH_BY_QUERY=1 (или свой шаблон url_template со своим q) —
# если Авито изменит поведение либо если у вас прокси, с которого поиск идёт.
# Проверка формы ссылки:  python3 collect.py --check-query "iphone 13 pro"
# С включённым скрапером поиск по тексту снова имеет смысл: он обходит
# блокировку и отдаёт карточки. Без скрапера q= бесполезен — Авито даёт 0.
# Поиск по тексту ВКЛЮЧЁН по умолчанию: проверено на живом сайте 29.10.2026 —
# ссылка «раздел + q=» отдаёт полную выдачу (3,4 МБ карточек), в отличие от
# «/all?q=» без раздела. Без q сборщик качал весь раздел и по критериям
# «куртка nike» находок не было вовсе.
# Поиск по словам (q=) Авито закрывает почти всегда (439) — проверено
# 30.10.2026 на трёх IP. Поэтому по умолчанию идём по РАЗДЕЛУ, а слова
# критерия отсеиваются на сервере. Так работает то, что площадка отдаёт.
SEARCH_BY_QUERY = os.environ.get('POLKA_SEARCH_BY_QUERY', '0') != '0'

USER_AGENT = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
              "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36")

# Признаки того, что нас остановили — по ним сразу выходим, а не долбим сайт
BLOCK_MARKERS = ('captcha', 'showcaptcha', 'Доступ ограничен', 'проблема с IP',
                 'IP-адрес', 'подтвердите, что вы не робот', 'blocked')

# Признаки того, что лот больше не продаётся. Авито не отдаёт статус
# в выдаче — узнаём только переоткрыв страницу.
GONE_MARKERS = ('объявление снято', 'снято с публикации', 'объявление не найдено',
                'страница не найдена', 'товар продан', 'продано', 'объявление удалено',
                'это объявление больше не доступно')


# Маркеры страницы ОДНОГО объявления (на странице выдачи их нет, поэтому
# fetch() их не проверяет, а fetch_item() — проверяет).
ITEM_MARKERS = ('item-view/title-info', 'item-view/item-description',
                'item-view/item-price', 'seller-info/name')
# Короткая страница: если в ней ещё и маркер капчи — это блокировка.
SHORT_PAGE_CHARS = 20000
# Авито не пустил на страницу объявления в этом проходе: описания пропускаем
# до следующего прохода, чтобы не долбить сайт и не валить весь сбор.
_DETAILS_BLOCKED = False
_DETAILS_BLOCKED_SINCE = 0.0
# После 439 сборщик пережидает и пробует САМ, без ручного перезапуска.
# Одна попытка за 30 минут ничего не жжёт, а блок Авито обычно спадает
# за 1–2 часа — через 2–4 попытки описания снова пойдут.
DETAILS_BLOCK_RETRY_SEC = 1800
# Сколько символов описания хранить. Дальше — маркетинговый шум продавца.
DESC_MAX_CHARS = 2000


class Blocked(Exception):
    """Сайт показал капчу или ограничение — прекращаем работу."""


# Прокси для обхода блокировки по IP. Авито не пускает адреса дата-центров
# (проверено: сервер Amvera получает 429 «проблема с IP» на первом запросе),
# а резидентный или мобильный прокси выглядит как обычный домашний абонент.
# Формат: http://логин:пароль@хост:порт
# Внешний скрапер (ScrapingBee): обходит гео-блокировки Авито без прокси.
# Бесплатный тариф — 1000 кредитов, один запрос = 1-25 кредитов в зависимости
# от рендера. Включается переменной SCRAPINGBEE_KEY.
SCRAPINGBEE_KEY = os.environ.get('SCRAPINGBEE_KEY', '')
SCRAPINGBEE_URL = 'https://app.scrapingbee.com/api/v1/'
_SCRAPER_BROKEN = []   # заполняется, если скрапер ответил 401
# Бюджет скрапера на один проход: 1000 бесплатных кредитов, ~25 на страницу.
# Тратим не больше 4 страниц за проход, чтобы запаса хватило на несколько дней,
# а не на один прогон.
SCRAPER_PAGES_PER_RUN = int(os.environ.get('SCRAPER_PAGES_PER_RUN', '4'))
_SCRAPER_USED = []
PROXY = os.environ.get('POLKA_PROXY', '')
_OPENER = None

# ── Главное открытие ────────────────────────────────────────────────────────
# Авито блокирует не только по IP, но и по ОТПЕЧАТКУ КЛИЕНТА. Обычный Python
# и даже подделка под Chrome получают 429, а клиент с отпечатком Safari —
# HTTP 200 и полную выдачу. Проверено на живом сайте: 3 запроса подряд, 50
# карточек каждый. Поэтому ходим через curl_cffi, а не через urllib.
try:
    from curl_cffi import requests as _cffi
except Exception:
    _cffi = None

# Авито пропускает не всегда: несколько запросов проходят, потом 429.
# Поэтому перебираем отпечатки — какой-то из них в этот момент проходит, —
# и запоминаем удачный, чтобы не тратить попытки впустую.
IMPERSONATE = os.environ.get('POLKA_IMPERSONATE', 'safari')
IMPERSONATE_POOL = ('safari', 'safari17_0', 'safari15_3', 'chrome131',
                    'edge101', 'firefox133', 'chrome')
_WORKING_PROFILE = None


# ── Cookies между проходами ────────────────────────────────────────────────
# Авито лучше относится к «постоянному посетителю», чем к потоку запросов без
# памяти: с сохранённой сессией меньше поводов выдать 429/439. Cookies лежат
# рядом со сборщиком, по одному набору на отпечаток браузера. При блокировке
# набор сбрасывается и запрос повторяется как «новый посетитель».
COOKIES_FILE = os.environ.get(
    'POLKA_COOKIES',
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cookies.json'))
_COOKIE_JAR = None          # профиль → {имя: значение}
_SESSIONS = {}              # профиль → curl_cffi.Session


def _cookies_load() -> dict:
    global _COOKIE_JAR
    if _COOKIE_JAR is None:
        try:
            with open(COOKIES_FILE, encoding='utf-8') as fh:
                data = json.load(fh)
            _COOKIE_JAR = data if isinstance(data, dict) else {}
        except Exception:
            _COOKIE_JAR = {}
    return _COOKIE_JAR


def _cookies_save() -> None:
    try:
        with open(COOKIES_FILE, 'w', encoding='utf-8') as fh:
            json.dump(_COOKIE_JAR or {}, fh, ensure_ascii=False)
    except Exception:
        pass


def rotate_proxy_session() -> str:
    """Меняет сессию резидентского прокси (новый IP) и возвращает адрес.

    Провайдеры дают «липкую» сессию параметром _hardsession-XXXX: пока он
    один и тот же, IP не меняется, и Авито быстро помечает его. Подставляем
    случайный — следующая попытка идёт уже с другого адреса.
    """
    global PROXY
    import secrets as _secrets
    cur = str(PROXY or '')
    if not cur:
        return ''
    m = re.search(r'(hardsession-)([^_@/?&]+)', cur)
    if not m:
        return cur
    new_id = _secrets.token_urlsafe(8).replace('-', '').replace('_', '')[:10]
    PROXY = cur[:m.start(2)] + new_id + cur[m.end(2):]
    return PROXY


def _session_for(profile: str):
    """Сессия для отпечатка: держит cookies между запросами и проходами."""
    if _cffi is None:
        return None
    sess = _SESSIONS.get(profile)
    if sess is None:
        try:
            sess = _cffi.Session(impersonate=profile)
        except Exception:
            return None
        # Просим сжатие: страница Авито весит 3,8 МБ, а с brotli приходит
        # около 0,4 МБ. Прокси у нас лимитированный, поэтому это критично.
        try:
            sess.headers.update({'Accept-Encoding': 'br, gzip, deflate'})
        except Exception:
            pass
        saved = _cookies_load().get(profile) or {}
        for name, value in saved.items():
            try:
                sess.cookies.set(name, value)
            except Exception:
                pass
        _SESSIONS[profile] = sess
    return sess


def _cookies_remember(profile: str, sess) -> None:
    """Запоминает cookies после удачного ответа."""
    jar = _cookies_load()
    try:
        jar[profile] = {c.name: c.value for c in sess.cookies.jar}
    except Exception:
        try:
            jar[profile] = dict(sess.cookies)
        except Exception:
            return
    _cookies_save()


def _cookies_drop(profile: str) -> None:
    """Сбрасывает набор: при блокировке начинаем как новый посетитель."""
    jar = _cookies_load()
    if jar.pop(profile, None) is not None:
        _cookies_save()
    _SESSIONS.pop(profile, None)


def _opener():
    """Открывалка запросов. Собирается один раз, с прокси или без."""
    global _OPENER
    if _OPENER is None:
        handlers = []
        if PROXY:
            handlers.append(urllib.request.ProxyHandler({'http': PROXY, 'https': PROXY}))
        # На macOS у системного python3 часто нет корневых сертификатов, и
        # запрос падает с CERTIFICATE_VERIFY_FAILED — это выглядит как
        # блокировка, хотя дело в локальной настройке. Если есть certifi,
        # берём сертификаты оттуда.
        try:
            import certifi
            handlers.append(urllib.request.HTTPSHandler(
                context=ssl.create_default_context(cafile=certifi.where())))
        except Exception:
            pass
        _OPENER = urllib.request.build_opener(*handlers)
    return _OPENER


# ── Цели по умолчанию ───────────────────────────────────────────────────────
# Проверены на живом Авито: каждая отдаёт 50–80 объявлений.
#
# Зачем в коде, а не только в config.json: на сервере config.json нет —
# он в .gitignore, потому что содержит токен. Без этого списка серверный
# сборщик запускался с нулём целей и не собирал НИЧЕГО.
#
# Форма адреса: /all/ — вся Россия. /rossiya/ Авито отдаёт пустой страницей.
DEFAULT_CATEGORIES = [
    ("Электроника", "telefony"),
    ("Электроника", "noutbuki"),
    ("Электроника", "planshety_i_elektronnye_knigi"),
    ("Электроника", "nastolnye_kompyutery"),
    ("Электроника", "igry_pristavki_i_programmy"),
    ("Электроника", "audio_i_video"),
    ("Электроника", "bytovaya_tehnika"),
    ("Электроника", "tovary_dlya_kompyutera"),
    ("Одежда, обувь, аксессуары", "odezhda_obuv_aksessuary"),
    ("Хобби и отдых", "hobbi_i_otdyh"),
    ("Транспорт", "avtomobili"),
    ("Недвижимость", "kvartiry"),
    ("Работа и подработка", "rabota"),
    ("Другое", "velosipedy"),
    ("Другое", "muzykalnye_instrumenty"),
    ("Другое", "krasota_i_zdorove"),
]


# ?s=104 — сортировка Авито «по дате». Проверено на живом сайте: с ней
# выдача состоит ТОЛЬКО из свежих объявлений (49 из 49 — по часу давности),
# а без неё даты есть у 10 из 50 и попадается недельное старьё.
DATE_SORT = "?s=104"


def default_targets() -> list:
    cats = DEFAULT_CATEGORIES
    # На сервере Amvera контейнер слабее, чем домашний Mac: ограничиваем
    # число категорий, иначе сбор съедает память и сервис уходит в перезапуск.
    try:
        limit = int(os.environ.get('POLKA_MAX_CATEGORIES', '0') or 0)
    except ValueError:
        limit = 0
    if limit > 0:
        cats = cats[:limit]
    return [{"source": "avito", "url": f"https://www.avito.ru/all/{slug}{DATE_SORT}",
             "city": "Россия", "category": cat} for cat, slug in cats]


def _fetch_via_scraper(url: str, timeout: int = 60) -> str:
    """Запрос через ScrapingBee: их IP и их браузер, наша только ссылка."""
    from urllib.parse import urlencode
    q = urlencode({'api_key': SCRAPINGBEE_KEY, 'url': url, 'country_code': 'ru',
                   'render_js': 'false', 'premium_proxy': 'true'})
    req = urllib.request.Request(SCRAPINGBEE_URL + '?' + q,
                                 headers={'User-Agent': USER_AGENT})
    with _opener().open(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', 'ignore')


# Профиль браузера, в котором один раз пройдена проверка Авито. Когда задан,
# страницы берём настоящим Chromium с этим профилем: только так Авито пускает
# (headless он блокирует, прямые запросы — тоже).
AVITO_PROFILE = os.environ.get('AVITO_PROFILE', '')
AVITO_PARSER_DIR = os.environ.get(
    'AVITO_PARSER_DIR',
    '/Users/nikitagereev/Documents/deepseek-harness/default-workspace/avito-parser 2')

_avito_fetcher = None


def _fetch_via_profile(url: str, timeout: int = 120) -> str:
    """Страница через Chromium с сохранённым профилем (проверка уже пройдена)."""
    global _avito_fetcher
    if AVITO_PARSER_DIR not in sys.path:
        sys.path.insert(0, AVITO_PARSER_DIR)
    from avitoparser.fetch import FetchConfig, PlaywrightFetcher
    if _avito_fetcher is None:
        _avito_fetcher = PlaywrightFetcher(FetchConfig(
            headless=False, user_data_dir=AVITO_PROFILE, timeout=timeout, delay=0))
    res = _avito_fetcher.get(url)
    return getattr(res, 'text', '') or ''


def _fetch_direct_body(url: str, timeout: int = 25) -> str:
    """Прямой запрос: перебор отпечатков, без внешних сервисов."""
    req = urllib.request.Request(url, headers={
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'ru-RU,ru;q=0.9',
        # Без Referer Авито чаще отвечает 429: запрос выглядит как прямой
        # заход в поиск без browsing-контекста.
        'Referer': 'https://www.avito.ru/',
        'Upgrade-Insecure-Requests': '1',
    })
    # Основной путь: перебираем отпечатки, пока какой-нибудь не пройдёт
    if _cffi is not None:
        global _WORKING_PROFILE
        proxies = {'http': PROXY, 'https': PROXY} if PROXY else None
        # Удачный отпечаток пробуем первым: он уже доказал, что работает
        order = list(IMPERSONATE_POOL)
        if _WORKING_PROFILE and _WORKING_PROFILE in order:
            order.remove(_WORKING_PROFILE)
            order.insert(0, _WORKING_PROFILE)
        last_error = 'ни один отпечаток не прошёл'
        # Блок означает «не сейчас»: перебирать четыре отпечатка — это
        # четыре лишних запроса и более длинный бан. При 429/439 выходим
        # сразу, максимум одна повторная попытка со сменой IP.
        max_attempts = int(os.environ.get('POLKA_MAX_ATTEMPTS', '1') or 1)
        order = order[:max(1, max_attempts)]
        for profile in order:
            # Сессия нужна, чтобы cookies жили между запросами и проходами
            sess = _session_for(profile)
            _mark_request()
            # Сжатие просим в самом запросе: страница Авито весит 3,5 МБ
            # без него и ~0,4 МБ с brotli. Прокси считает мегабайты, так что
            # это главная экономия.
            _hdrs = {'Accept-Encoding': 'br, gzip, deflate'}
            try:
                if sess is not None:
                    r = sess.get(url, timeout=timeout, proxies=proxies, headers=_hdrs)
                else:
                    r = _cffi.get(url, impersonate=profile, timeout=timeout,
                                  proxies=proxies, headers=_hdrs)
            except Exception as exc:
                last_error = f"{profile}: {str(exc)[:70]}"
                rotate_proxy_session()
                proxies = {'http': PROXY, 'https': PROXY} if PROXY else None
                continue
            try:
                FETCH_BYTES[0] += int(r.headers.get('content-length') or len(r.content or b''))
            except Exception:
                pass
            if r.status_code in (403, 429) or 'data-marker="item"' not in r.text:
                last_error = f"{profile}: HTTP {r.status_code}"
                # Сначала официальный способ: сменить IP по API провайдера.
                if PROXY and not _ROTATED_BY_API[0] and apply_rotation():
                    _ROTATED_BY_API[0] = True
                    _resources_reset()
                    continue
                rotate_proxy_session()
                proxies = {'http': PROXY, 'https': PROXY} if PROXY else None
                # Блокировка: старые cookies могли «запомнить» нас как проблемного
                # посетителя — сбрасываем и в следующий раз приходим заново.
                if r.status_code in (403, 429) and sess is not None:
                    _cookies_drop(profile)
                time.sleep(random.uniform(2.0, 5.0))
                continue
            # Короткая страница без разметки выдачи — заглушка антибота,
            # а не пустой результат. Уходим на паузу, а не долбим площадку
            # каждые полчаса и не тратим трафик.
            if len(r.text or '') < 200_000:
                raise Blocked(f'{profile}: заглушка вместо выдачи '
                              f'({len(r.text or "")} байт)')
            try:
                if _VERBOSE_COMPRESSION[0]:
                    print(f"  сжатие ответа: {r.headers.get('content-encoding') or 'нет'} "
                          f"| размер по сети: {r.headers.get('content-length') or '?'}")
            except Exception:
                pass
            if sess is not None:
                _cookies_remember(profile, sess)
            _WORKING_PROFILE = profile
            if profile != IMPERSONATE:
                print(f"  (сработал отпечаток {profile})")
            return r.text
        raise Blocked(last_error)
        if r.status_code in (403, 429):
            raise Blocked(f"HTTP {r.status_code} — доступ ограничен по IP")
        html_cffi = r.text
        # Признаки блокировки проверяем ТОЛЬКО если карточек нет: слово
        # captcha встречается и на обычной странице выдачи, и раньше это
        # давало ложное «нас заблокировали» на живых данных.
        if 'data-marker="item"' not in html_cffi:
            low_cffi = html_cffi.lower()
            for marker in BLOCK_MARKERS:
                if marker.lower() in low_cffi:
                    raise Blocked(f"похоже на блокировку (нашли «{marker}»)")
        return html_cffi

    # Без curl_cffi шансов почти нет, но оставляем запасной путь

    # Запасной путь, если curl_cffi не установлен: обычно получает 429
    try:
        with _opener().open(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        # 429 и 403 Авито отдаёт на «плохой» IP. Это НЕ обычная ошибка:
        # без этой ветки сборщик счёл бы её временной и пошёл долбить дальше,
        # закрепляя блокировку. Проверено: наш IP получает 429 с текстом
        # «Доступ ограничен: проблема с IP» на первом же запросе.
        if exc.code in (403, 429):
            raise Blocked(f"HTTP {exc.code} — доступ ограничен по IP")
        raise
    html = raw.decode('utf-8', errors='replace')
    if 'data-marker="item"' not in html:
        low = html.lower()
        for marker in BLOCK_MARKERS:
            if marker.lower() in low:
                raise Blocked(f"похоже на блокировку (нашли «{marker}»)")
    return html


# Сколько байт скачано за проход: прокси у нас лимитированный, трафик надо видеть
FETCH_BYTES = [0]
# Минимальный интервал между ЛЮБЫМИ запросами к Авито: два подряд — уже
# повод для 429. Значение настраивается, по умолчанию 90 секунд.
# Пауза между запросами: случайная в диапазоне, чтобы не выглядеть
# роботом с ровным шагом.
MIN_REQUEST_GAP = int(os.environ.get('POLKA_REQUEST_GAP', '90'))
MAX_REQUEST_GAP = int(os.environ.get('POLKA_REQUEST_GAP_MAX', '240'))
_LAST_REQUEST_TS = [0.0]
# Сколько блокировок подряд: увеличивает паузу, успех — сбрасывает
_BLOCK_BACKOFF = [0]


def block_cool_down(base_min: int = 45) -> None:
    """Отдых после блокировки: растёт с каждым блоком, но не бесконечно.

    Авито снимает метку за 30–120 минут. Спим порциями по 5 минут, чтобы
    процесс можно было остановить, и печатаем остаток — видно, что работаем,
    а не висим.
    """
    import random as _rnd
    try:
        mins = min(180, max(20, base_min + _BLOCK_BACKOFF[0] * 20))
        mins += _rnd.randint(0, 10)
    except Exception:
        mins = base_min
    print(f"  😴 отдых {mins} мин после блокировки (шаг {_BLOCK_BACKOFF[0]})")
    left = mins * 60
    while left > 0:
        chunk = min(300, left)
        time.sleep(chunk)
        left -= chunk
        if left:
            print(f"     ещё {left // 60} мин…")
    _BLOCK_BACKOFF[0] = 0


def _respect_rate_limit() -> None:
    """Держит паузу между запросами к Авито внутри процесса."""
    try:
        if MIN_REQUEST_GAP <= 0:
            return
        gap = time.time() - _LAST_REQUEST_TS[0]
        # Растущая пауза после блокировок: чем чаще нас режут, тем медленнее
        # идём. Сбрасывается при успешной странице.
        need = random.randint(MIN_REQUEST_GAP, max(MIN_REQUEST_GAP, MAX_REQUEST_GAP))
        need += min(600, _BLOCK_BACKOFF[0] * 60)
        if _LAST_REQUEST_TS[0] and gap < need:
            time.sleep(need - gap)
    except Exception:
        pass


def _mark_request() -> None:
    try:
        _LAST_REQUEST_TS[0] = time.time()
    except Exception:
        pass



# ── API прокси-провайдера: смена IP по официальному эндпоинту ────────────
PROXY_API_BASE = os.environ.get('PROXY_API_BASE',
                                'https://public-api.proxxxymiron.com/v1')
PROXY_API_KEY = os.environ.get('PROXY_API_KEY', '')
_PENDING_ROTATION = {'url': '', 'expires': ''}
# Один раз за проход пробуем сменить IP через API, чтобы не спамить
_ROTATED_BY_API = [False]
# Последняя ошибка API провайдера — показываем в диагностике
PROXY_API_ERROR = ['']
_VERBOSE_COMPRESSION = [str(os.environ.get('POLKA_VERBOSE', '1')) != '0']


def _resources_reset() -> None:
    """После смены IP старые сессии бесполезны — начинаем заново."""
    try:
        _SESSIONS.clear()
    except Exception:
        pass


def proxy_credentials() -> tuple:
    """Достаёт логин и пароль из адреса прокси."""
    try:
        from urllib.parse import urlsplit, unquote
        sp = urlsplit(str(PROXY or ''))
        return unquote(sp.username or ''), unquote(sp.password or '')
    except Exception:
        return '', ''


def proxy_product() -> str:
    """Код продукта для API: rp — резидентские, mp — мобильные."""
    host = str(PROXY or '').lower()
    if 'mobile' in host or '_mp' in host:
        return 'mp'
    if 'pr.' in host or 'pro.' in host:
        return 'pr'
    if 'dc' in host:
        return 'dcp'
    return 'rp'


def create_rotation_link(api_key: str = '') -> str:
    """Просит у провайдера ссылку смены IP и возвращает её."""
    key = str(api_key or PROXY_API_KEY or '').strip()
    if not key:
        return ''
    user, pwd = proxy_credentials()
    if not user or not pwd:
        return ''
    payload = {'proxies': [{'product': proxy_product(),
                            'username': user, 'password': pwd}]}
    try:
        # curl_cffi надёжнее системного urllib: у него свои корневые
        # сертификаты и современный TLS. С urllib сервер провайдера
        # закрывал соединение («Remote end closed connection»).
        if _cffi is not None:
            r = _cffi.post(f'{PROXY_API_BASE}/rotation-links', json=payload,
                           headers={'X-API-Key': key}, timeout=25)
            data = r.json()
        else:
            req = urllib.request.Request(
                f'{PROXY_API_BASE}/rotation-links',
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json', 'X-API-Key': key},
                method='POST')
            with _opener().open(req, timeout=25) as resp:
                data = json.loads(resp.read().decode('utf-8', 'ignore'))
        PROXY_API_ERROR[0] = ''
        results = ((data or {}).get('data') or {}).get('results') or []
        for item in results:
            if item.get('status') == 'created' and item.get('rotationUrl'):
                _PENDING_ROTATION['url'] = str(item['rotationUrl'])
                _PENDING_ROTATION['expires'] = str(item.get('expiresAt') or '')
                print('  ↻ получена ссылка смены IP')
                return _PENDING_ROTATION['url']
        err = results[0].get('error') if results else None
        if err:
            PROXY_API_ERROR[0] = str(err.get('code') or '') + ': ' + str(err.get('message') or '')
        else:
            PROXY_API_ERROR[0] = str((data or {}).get('error') or 'нет ссылки в ответе')[:200]
        print(f"  API ротации: {err or data}")
    except Exception as exc:
        PROXY_API_ERROR[0] = str(exc)[:200]
        print(f"  API ротации не ответил: {str(exc)[:80]}")
    return ''


def apply_rotation(api_key: str = '') -> bool:
    """Открывает ссылку смены IP. True — IP сменён."""
    url = _PENDING_ROTATION.get('url') or create_rotation_link(api_key)
    if not url:
        return False
    try:
        if _cffi is not None:
            _cffi.get(url, headers={'User-Agent': USER_AGENT}, timeout=25)
        else:
            req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
            with _opener().open(req, timeout=25) as resp:
                resp.read()
        _PENDING_ROTATION['url'] = ''
        print('  ↻ IP прокси сменён через API')
        return True
    except Exception as exc:
        print(f"  смена IP не удалась: {str(exc)[:70]}")
        return False


def proxy_exit_ip() -> str:
    """Внешний IP через прокси. Только curl_cffi: urllib не умеет SOCKS."""
    if not PROXY:
        return ''
    proxies = {'http': PROXY, 'https': PROXY}
    try:
        if _cffi is not None:
            # Профиль берём из рабочего пула: 'safari' как имя отпечатка
            # curl_cffi не знает и падает с ошибкой.
            _profile = IMPERSONATE if IMPERSONATE in IMPERSONATE_POOL else IMPERSONATE_POOL[1]
            r = _cffi.get('https://api.ipify.org', proxies=proxies,
                          impersonate=_profile, timeout=25)
            return (r.text or '').strip()
        return ''
    except Exception as exc:
        PROXY_API_ERROR[0] = str(exc)[:160]
        return ''


def warm_up() -> bool:
    """«Прогрев»: открываем главную Авито, чтобы получить штатные cookies.

    Человек сначала заходит на сайт, потом в раздел. Запрос сразу в выдачу
    без cookies выглядит как бот и чаще ловит 429.
    """
    try:
        sess = _session_for(IMPERSONATE_POOL[1])
        if sess is None:
            return False
        _mark_request()
        r = sess.get('https://www.avito.ru/', timeout=25,
                     proxies={'http': PROXY, 'https': PROXY} if PROXY else None)
        ok = r.status_code == 200
        if ok:
            _cookies_remember(IMPERSONATE_POOL[1], sess)
            print('  прогрев: cookies получены')
        return ok
    except Exception as exc:
        print(f'  прогрев не удался: {str(exc)[:60]}')
        return False


def fetch(url: str, timeout: int = 25, prefer_scraper: bool = False) -> str:
    """Сначала напрямую (бесплатно). Скрапер — если поймали 439/429.

    prefer_scraper=True — сразу через скрапер: так берём страницы с q=
    (поиск по тексту), которые обычный запрос от Авито не получает.
    """
    if (prefer_scraper and SCRAPINGBEE_KEY and not _SCRAPER_BROKEN
            and len(_SCRAPER_USED) < SCRAPER_PAGES_PER_RUN and 'avito.ru' in url):
        _SCRAPER_USED.append(url)
        try:
            return _fetch_via_scraper(url, timeout=max(timeout, 60))
        except Exception as exc:
            msg = str(exc)
            print(f"  скрапер не отдал страницу: {msg[:70]}")
            if '401' in msg or 'UNAUTHORIZED' in msg.upper():
                # Ключ недействителен или кончились кредиты: выключаем флаг,
                # чтобы дальше не тратить по минуте на каждую страницу.
                _SCRAPER_BROKEN.append(True)
                print("  скрапер отключён до конца прохода (401)")
    if 'avito.ru' in url:
        _respect_rate_limit()
    if AVITO_PROFILE and 'avito.ru' in url:
        try:
            return _fetch_via_profile(url, timeout=max(timeout, 120))
        except Exception as exc:
            print(f"  ⚠ профиль не сработал: {str(exc)[:80]}")
    if SCRAPINGBEE_KEY and 'avito.ru' in url:
        try:
            return _fetch_direct_body(url, timeout)
        except Exception as exc:
            if '439' in str(exc) or '429' in str(exc):
                print("  прямой запрос заблокирован — беру скрапер")
                return _fetch_via_scraper(url, timeout=max(timeout, 60))
            raise
    return _fetch_direct_body(url, timeout)


def fetch_item(url: str, timeout: int = 20) -> str:
    """Страница ОДНОГО объявления — оттуда берём описание и продавца.

    Отдельно от fetch(): тот считает ответ валидным только при наличии
    data-marker="item" — это маркер СТРАНИЦЫ ВЫДАЧИ. На странице объявления
    его нет, поэтому fetch(url) перебирал весь пул отпечатков (по 2–5 с
    паузой после каждого), получал 439 и бросал Blocked. Итог: описания не
    собирались никогда, а Авито получал 4–5 лишних запросов на объявление.

    Здесь ровно ОДИН запрос рабочим отпечатком (если он ещё не найден —
    первым из пула), таймаут 20 с. Блокировка = статус 403/429/439 или
    маркеры капчи на короткой странице.
    """
    if _cffi is not None:
        global _WORKING_PROFILE
        profile = _WORKING_PROFILE or IMPERSONATE_POOL[0]
        proxies = {'http': PROXY, 'https': PROXY} if PROXY else None
        try:
            r = _cffi.get(url, impersonate=profile, timeout=timeout, proxies=proxies)
        except Exception as exc:
            raise Blocked(f"{profile}: {str(exc)[:70]}")
        text = r.text or ''
        if r.status_code in (403, 429, 439):
            raise Blocked(f"HTTP {r.status_code} — доступ ограничен по IP")
        if len(text) < SHORT_PAGE_CHARS:
            low = text.lower()
            for marker in BLOCK_MARKERS:
                if marker.lower() in low:
                    raise Blocked(f"похоже на блокировку (нашли «{marker}»)")
        if not any(m in text for m in ITEM_MARKERS):
            raise Blocked("страница объявления не распознана (нет знакомых маркеров)")
        _WORKING_PROFILE = profile
        return text

    # Без curl_cffi — обычный urllib; проверки те же
    req = urllib.request.Request(url, headers={
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'ru-RU,ru;q=0.9',
    })
    try:
        with _opener().open(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        if exc.code in (403, 429, 439):
            raise Blocked(f"HTTP {exc.code} — доступ ограничен по IP")
        raise
    text = raw.decode('utf-8', errors='replace')
    if len(text) < SHORT_PAGE_CHARS:
        low = text.lower()
        for marker in BLOCK_MARKERS:
            if marker.lower() in low:
                raise Blocked(f"похоже на блокировку (нашли «{marker}»)")
    if not any(m in text for m in ITEM_MARKERS):
        raise Blocked("страница объявления не распознана (нет знакомых маркеров)")
    return text


# ── Разбор страницы ─────────────────────────────────────────────────────────
# «2 000 ₽/мес» — это платёж, а не цена товара: такие карточки пропускаем
PER_MONTH_MARKERS = ('/мес', 'в месяц', 'мес.', 'месяц', 'рассрочк', 'за месяц',
                     'первый взнос', 'взнос')


def parse_price(text) -> int:
    """Цена из текста карточки. Осторожно с разделителями и рассрочкой.

    Было: все нецифровые символы вырезались, и «1 250,50 ₽» превращалось в
    125050 — объявление уходило в ленту с ценой в сто раз больше. Теперь:
      «1 250 ₽» → 1250, «1 250,50» → 1250, «1250.50» → 1250,
      «1.250.000» → 1250000, «от 1 200 ₽» → 1200,
      «10 000 – 12 000 ₽» → 10000 (нижняя граница),
      «2 000 ₽/мес» → 0 (платёж, а не цена: карточка пропускается),
      «бесплатно» → 0.
    """
    if isinstance(text, (int, float)):
        return int(text)
    raw = str(text or '').strip().lower()
    if not raw:
        return 0
    if any(marker in raw for marker in PER_MONTH_MARKERS):
        return 0
    m = re.search(r'\d[\d\s\u00a0]*(?:[.,]\d+)*', raw)
    if not m:
        return 0
    num = m.group(0).replace('\u00a0', '').replace(' ', '')
    if re.fullmatch(r'\d{1,3}(?:[.,]\d{3})+', num):
        # «1.250.000» — разделители тысяч, а не дробная часть
        num = re.sub(r'[.,]', '', num)
    else:
        num = num.replace(',', '.')
    try:
        return int(float(num))
    except ValueError:
        return 0


def external_id_from_url(url: str) -> str:
    """Авито: .../some-title_123456789 → 123456789. Юла: .../offer/abc-123 → abc-123."""
    m = re.search(r'_(\d{6,})(?:\?|$)', url or '')
    if m:
        return m.group(1)
    m = re.search(r'/([0-9a-f]{8}-[0-9a-f-]{20,})', url or '', re.I)
    if m:
        return m.group(1)
    m = re.search(r'/(\d{6,})(?:\?|$)', url or '')
    if m:
        return m.group(1)
    return ''


def items_from_jsonld(html: str) -> list:
    """Самый надёжный путь: сайты кладут разметку schema.org для поисковиков."""
    out = []
    for block in re.findall(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>',
                            html, re.S | re.I):
        try:
            data = json.loads(unescape(block.strip()))
        except Exception:
            continue
        for node in (data if isinstance(data, list) else [data]):
            if not isinstance(node, dict):
                continue
            graph = node.get('@graph') if isinstance(node.get('@graph'), list) else [node]
            for item in graph:
                if not isinstance(item, dict):
                    continue
                offers = item.get('offers')
                if isinstance(offers, list):
                    offers = offers[0] if offers else {}
                price = parse_price((offers or {}).get('price')) if isinstance(offers, dict) else 0
                url = item.get('url') or (offers or {}).get('url') if isinstance(offers, dict) else item.get('url')
                name = item.get('name') or item.get('headline')
                if name and price and url:
                    images = item.get('image')
                    if isinstance(images, str):
                        images = [images]
                    out.append({
                        'title': str(name)[:200],
                        'price': price,
                        'url': str(url),
                        'photos': [str(i) for i in (images or []) if isinstance(i, str)][:5],
                        'external_id': external_id_from_url(str(url)),
                        'city': '',
                    })
    return out


def seller_type_from_node(node: dict) -> str:
    """Частник или магазин — по данным КАРТОЧКИ СПИСКА, без захода на страницу.

    Раньше тип продавца доставался только со страницы объявления, а она
    требует домашнего IP или прокси (520/429 с дата-центров). Из-за этого
    условие «только с рук» не проверялось вовсе.
    """
    if not isinstance(node, dict):
        return ''
    for key in ('sellerType', 'seller_type'):
        value = str(node.get(key) or '').lower()
        if value in ('company', 'shop', 'brand'):
            return 'company'
        if value in ('private', 'person', 'individual'):
            return 'private'
    if node.get('isCompany') is True or node.get('companyName'):
        return 'company'
    for key in ('seller', 'sellerInfo', 'iva', 'sellerData'):
        sub = node.get(key)
        if isinstance(sub, dict):
            found = seller_type_from_node(sub)
            if found:
                return found
    return ''


def seller_type_from_card(chunk: str) -> str:
    """То же по разметке карточки: у магазина есть ссылка /brands/ или подпись."""
    low = chunk.lower()
    if '/brands/' in low or '>компания<' in low or 'магазин' in low:
        return 'company'
    if 'частное лицо' in low or '>частник<' in low:
        return 'private'
    return ''


def items_from_initial_data(html: str) -> list:
    """Второй путь: Авито кладёт данные страницы в window.__initialData__."""
    out = []
    m = re.search(r'window\.__initialData__\s*=\s*"([^"]+)"', html)
    if not m:
        return out
    try:
        from urllib.parse import unquote
        payload = json.loads(unquote(m.group(1)))
    except Exception:
        return out

    def walk(node):
        if isinstance(node, dict):
            title = node.get('title')
            price = node.get('priceDetailed') or node.get('price')
            if isinstance(price, dict):
                price = price.get('value')
            url = node.get('urlPath') or node.get('url')
            if title and price and url:
                images = node.get('images') or []
                photos = []
                for img in images if isinstance(images, list) else []:
                    if isinstance(img, dict) and img.get('640x480'):
                        photos.append(img['640x480'])
                    elif isinstance(img, str):
                        photos.append(img)
                out.append({
                    'title': str(title)[:200],
                    'price': parse_price(price),
                    'url': url if str(url).startswith('http') else f"https://www.avito.ru{url}",
                    'photos': photos[:5],
                    'external_id': str(node.get('id') or '') or external_id_from_url(str(url)),
                    'city': str(node.get('location') or node.get('geo') or '')[:100],
                    'seller_type': seller_type_from_node(node),
                })
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(payload)
    return out


def hours_ago(text: str):
    """«7 дней назад» → 168 часов. «сегодня» → 0.

    Нужно, чтобы не присылать как «находку» объявление недельной давности:
    на Авито сверху выдачи висят как раз такие, и порядок там не по свежести.
    """
    t = str(text or '').lower().replace('\xa0', ' ').strip()
    if not t:
        return None
    if 'сегодня' in t or 'минут' in t or 'только что' in t or 'сейчас' in t:
        return 0
    if 'вчера' in t:
        return 24
    m = re.search(r'(\d+)?\s*(минут|час|день|дня|дней|сут|недел|месяц|год)', t)
    if not m:
        return None
    # «месяц назад» и «год назад» — без числа, поэтому n может быть пустым
    n = int(m.group(1)) if m.group(1) else 1
    unit = m.group(2)
    if unit.startswith('минут'):
        return 0
    if unit.startswith('час'):
        return n
    if unit.startswith(('день', 'дня', 'дней', 'сут')):
        return n * 24
    if unit.startswith('недел'):
        return n * 168
    if unit.startswith('месяц'):
        return n * 720
    if unit.startswith('год'):
        return n * 8760
    return None


def items_from_microdata(html: str) -> list:
    """Разбор микроразметки schema.org — ОСНОВНОЙ путь для Авито.

    Проверено на настоящей странице выдачи: карточки размечены атрибутами
    itemProp, а не JSON-LD, поэтому прежний разбор находил НОЛЬ карточек из 80.
    Классы у Авито хешированные (iva-item-title-KE8A9), так что цепляемся за
    itemProp — он смысловой и переживает пересборку вёрстки.
    """
    out = []
    for chunk in re.split(r'data-marker="item"', html)[1:]:
        chunk = chunk[:40000]

        def prop(name: str, attr: str = 'content') -> str:
            """Значение itemProp, в любом порядке атрибутов."""
            m = re.search(r'itemProp="%s"[^>]*?%s="([^"]*)"' % (name, attr), chunk, re.I)
            if m:
                return m.group(1)
            m = re.search(r'%s="([^"]*)"[^>]*?itemProp="%s"' % (attr, name), chunk, re.I)
            return m.group(1) if m else ''

        price = parse_price(prop('price'))
        if not price:
            # Проверено на живой выдаче: цена приходит текстом внутри блока
            # priceFlexContainerGrid («54 000 ₽»), а не в itemprop.
            m3 = re.search(r'priceLabelGrid[\s\S]{0,900}?([\d][\d\s]{2,12})\s*₽', chunk)
            if m3:
                price = parse_price(m3.group(1))
        if not price:
            m2 = re.search(r'itemprop="price"[^>]*content="([\d\s]+)"', chunk, re.I)
            if not m2:
                m2 = re.search(r'content="([\d\s]+)"[^>]*itemprop="price"', chunk, re.I)
            if m2:
                price = parse_price(m2.group(1))
        url = prop('url', 'href')
        if not url:
            m = re.search(r'href="(/[^"]+_\d{6,}[^"]*)"', chunk)
            url = m.group(1) if m else ''
        if url.startswith('/'):
            url = "https://www.avito.ru" + url

        # Заголовок лежит внутри <a>, поэтому между тегами допускаем вложенность
        title = ''
        m = re.search(r'item-title[^>]*>(?:\s*<[^>]+>)*\s*([^<]{3,200})', chunk)
        if m:
            title = unescape(re.sub(r'\s+', ' ', m.group(1))).strip()
        if not title:
            # Проверено на живой выдаче 24.10: заголовок лежит в alt картинки,
            # класса iva-item-title больше нет. Без этого разбиралось 0 карточек.
            m = re.search(r'<img[^>]*itemProp="image"[^>]*alt="([^"]{3,200})"', chunk, re.I)
            if not m:
                m = re.search(r'<img[^>]*alt="([^"]{3,200})"[^>]*itemProp="image"', chunk, re.I)
            if m:
                title = unescape(re.sub(r'\s+', ' ', m.group(1))).strip()

        m = re.search(r'data-item-id="(\d+)"', chunk)
        ext = m.group(1) if m else external_id_from_url(url)

        # Фото: Авито подгружает часть картинок лениво, поэтому кроме src
        # смотрим data-src и srcset. Без этого фотографии были лишь у 12
        # карточек из 50, а в приложении показывалась серая заглушка.
        photos = re.findall(r'itemProp="image"[^>]*?(?:data-)?src="([^"]+)"', chunk, re.I)
        if not photos:
            # srcSet: «url1 339w, url2 140w» — берём первый адрес
            for m2 in re.finditer(r'(?:srcSet|srcset)="([^"]+)"', chunk):
                first = m2.group(1).split(',')[0].strip().split(' ')[0]
                if first.startswith('http'):
                    photos.append(first)
        if not photos:
            photos = re.findall(r'(?:data-)?src="(https://[\w.-]*img\.avito\.st/[^"]+)"', chunk)
        if not photos:
            photos = re.findall(r"https://[\w.-]*img\.avito\.st/[^\s<>]+", chunk)
        photos = [x.strip('"\',') for x in photos if x.startswith("http")]
        photos = list(dict.fromkeys(p for p in photos if p))

        city = ''
        m = re.search(r'itemProp="addressLocality"[^>]*content="([^"]*)"', chunk, re.I)
        if m:
            city = unescape(m.group(1)).strip()

        # Дата публикации: без неё мы бы слали недельные объявления как находки
        m = re.search(r'data-marker="item-date"[^>]*>([^<]+)<', chunk)
        ago = hours_ago(m.group(1)) if m else None

        photos = [p.split(' ')[0] for p in photos]
        # Раньше требовалось ещё и url, и цену — на текущей вёрстке Авито
        # из-за этого отбрасывались ВСЕ карточки (проверено 24.10: 0 из 30).
        # Заголовок есть всегда, остальное добираем по возможности.
        # Продавец: в карточке явно помечено «Частное лицо» либо ссылка на
        # магазин. Без этого в промпт модели не уходило «частник/магазин»,
        # и требование «только частные» проверить было нечем.
        # Проверено на живой выдаче 27.10: продавца в карточке списка НЕТ —
        # ни «Частное лицо», ни ссылки на магазин. Поэтому пусто, а не
        # выдуманное значение: ложный «shop» хуже, чем неизвестно.
        seller_type = ''
        seller_name = ''
        if re.search(r'Частное лицо|Авито Доставка[^<]{0,20}частн', chunk, re.I):
            seller_type = 'private'
        elif re.search(r'data-marker="seller-link/link"[^>]*href="[^"]*/brands/', chunk, re.I):
            seller_type = 'shop'
        _sm = re.search(r'data-marker="seller-link/link"[^>]*>([^<]{2,60})<', chunk)
        if _sm:
            seller_name = unescape(_sm.group(1)).strip()[:60]
        if title:
            out.append({
                'title': title[:200],
                'price': price,
                'url': url.split('?')[0],
                'photos': photos[:5],
                'external_id': ext,
                'city': city,
                'hours_ago': ago,
                'seller_type': seller_type,
                'seller_name': seller_name,
            })
    return out


def items_from_html(html: str) -> list:
    """Третий путь: обычный разбор карточек, если разметки нет."""
    out = []
    for chunk in re.split(r'data-marker="item"', html)[1:]:
        chunk = chunk[:4000]
        link = re.search(r'href="(/[^"]+_\d{6,}[^"]*)"', chunk)
        title = re.search(r'item-title[^>]*>([^<]{3,200})<', chunk) or \
            re.search(r'<h3[^>]*>([^<]{3,200})</h3>', chunk)
        price = re.search(r'item-price[^>]*>([^<]{0,40})<', chunk) or \
            re.search(r'(\d[\d\s]{2,})\s*₽', chunk)
        img = re.search(r'src="(https://[^"]+\.(?:jpg|jpeg|png|webp))"', chunk)
        city = re.search(r'geo-address[^>]*>([^<]{2,60})<', chunk)
        if link and title and price:
            url = f"https://www.avito.ru{link.group(1)}"
            out.append({
                'title': unescape(re.sub(r'\s+', ' ', title.group(1))).strip()[:200],
                'price': parse_price(price.group(1)),
                'url': url,
                'photos': [img.group(1)] if img else [],
                'external_id': external_id_from_url(url),
                'city': unescape(city.group(1)).strip() if city else '',
                'seller_type': seller_type_from_card(chunk),
            })
    return out


class _MarkedText(HTMLParser):
    """Текст внутри элемента с нужным data-marker.

    Настоящий парсер, а не регулярка «до первого </div>»: описание на Авито
    размечено вложенными <p>, <br> и <div>, и прежний разбор обрывался на
    первой же вложенной закрывашке.
    """

    def __init__(self, marker: str):
        super().__init__(convert_charrefs=True)
        self.marker = marker
        self.tag = None
        self.depth = 0
        self.parts: list = []
        self.done = False

    def handle_starttag(self, tag, attrs):
        if self.done:
            return
        if self.depth == 0:
            if dict(attrs).get('data-marker') == self.marker:
                self.tag = tag
                self.depth = 1
            return
        if tag == self.tag:
            self.depth += 1
        if tag == 'br':
            self.parts.append('\n')
        elif tag in ('p', 'div', 'li'):
            self.parts.append('\n')

    def handle_startendtag(self, tag, attrs):
        if self.depth and tag == 'br':
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if self.done or not self.depth:
            return
        if tag == self.tag:
            self.depth -= 1
            if self.depth == 0:
                self.done = True
        elif tag in ('p', 'div', 'li'):
            self.parts.append('\n')

    def handle_data(self, data):
        if self.depth:
            self.parts.append(data)

    def text(self) -> str:
        raw = ''.join(self.parts).replace('\xa0', ' ')
        raw = re.sub(r'[ \t\r\f\v]+', ' ', raw)
        raw = re.sub(r' *\n *', '\n', raw)
        raw = re.sub(r'\n{3,}', '\n\n', raw)
        return raw.strip()


def text_from_marker(html: str, marker: str) -> str:
    """Текст элемента с data-marker=<marker> или ''."""
    parser = _MarkedText(marker)
    try:
        parser.feed(str(html or ''))
    except Exception:
        return ''
    return parser.text()


def _meta_content(html: str, key: str) -> str:
    """Содержимое <meta property|name="key" content="…">."""
    pat = (r'<meta[^>]+(?:property|name)=["\']%s["\'][^>]*content=["\']([^"\']*)'
           % re.escape(key))
    m = re.search(pat, html, re.I)
    if not m:
        pat2 = (r'<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:property|name)=["\']%s["\']'
                % re.escape(key))
        m = re.search(pat2, html, re.I)
    return unescape(m.group(1)).strip() if m else ''


def _jsonld_description(html: str) -> str:
    """Описание из структурированных данных (запасной путь)."""
    for m in re.finditer(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>',
                         html, re.S | re.I):
        try:
            data = json.loads(m.group(1).strip())
        except Exception:
            continue
        for node in (data if isinstance(data, list) else [data]):
            if not isinstance(node, dict):
                continue
            if node.get('description'):
                return str(node['description']).strip()
            for sub in (node.get('item') or [], node.get('itemListElement') or []):
                if isinstance(sub, dict) and sub.get('description'):
                    return str(sub['description']).strip()
    return ''


# Магазинные слова в имени продавца — как HUNT_SHOP_MARKERS в боте
SHOP_NAME_MARKERS = ('магазин', 'shop', 'store', 'салон', 'маркет', 'market',
                     'ооо', 'ип ', 'trade', 'техно', 'центр', 'company')


def parse_item_seller(html: str) -> dict:
    """Тип, имя и число объявлений продавца со страницы объявления.

    Логика та же, что в боте (_parse_seller), но проверки идут по блоку
    продавца, а не по всей странице: слово «компания» встречается и в тексте
    объявления, и тогда магазином ошибочно помечался частник.
    """
    out = {'seller_type': '', 'seller_name': '', 'seller_ads': 0}
    raw = str(html or '')
    low = raw.lower()
    if not low:
        return out
    seller_block = text_from_marker(raw, 'item-view/seller-info')
    seller_low = seller_block.lower()
    name = text_from_marker(raw, 'seller-info/name')
    if name:
        out['seller_name'] = re.sub(r'\s+', ' ', name).strip()[:60]
    if 'частное лицо' in seller_low or 'частное лицо' in low:
        out['seller_type'] = 'private'
    if '/brands/' in low or 'компания' in seller_low:
        out['seller_type'] = 'company'
    m = re.search(r'(\d[\d\s]{0,7})\s*объявлен', seller_low or low)
    if m:
        try:
            out['seller_ads'] = int(re.sub(r'\D', '', m.group(1)) or 0)
        except Exception:
            out['seller_ads'] = 0
    nm = str(out['seller_name']).lower()
    if out['seller_type'] != 'company' and any(w in nm for w in SHOP_NAME_MARKERS):
        out['seller_type'] = 'company'
    return out


# Характеристики объявления: на странице они лежат парами «название — значение»
# в JSON и в разметке. Описание берём как запасной вариант, но отбор идёт по
# характеристикам: состояние, размер, бренд, модель — то, что человек указал
# в критерии.
PARAM_LABELS = (
    'состояние', 'размер', 'размер одежды', 'размер обуви', 'бренд', 'модель',
    'цвет', 'материал', 'тип', 'пол', 'рост', 'объём памяти', 'аккумулятор',
    'год выпуска', 'пробег', 'комплектация', 'оригинальность', 'страна',
)


def parse_item_params(html: str) -> dict:
    """Достаёт характеристики объявления: {'Состояние': 'Хорошее', ...}."""
    out = {}
    text = str(html or '')
    # 1) JSON-пары вида "name":"Состояние","value":"Хорошее"
    for m in re.finditer(r'"name":"([^"]{2,40})"[^{}]{0,120}?"value":"([^"]{1,60})"', text):
        k, v = m.group(1).strip(), m.group(2).strip()
        if k.lower() in PARAM_LABELS and k not in out:
            out[k] = v
    # 2) Разметка: <li>Название: Значение</li> внутри блока параметров
    for m in re.finditer(r'<li[^>]*>\s*([А-Яа-яЁё ]{3,30}):\s*([^<]{1,60})</li>', text):
        k, v = m.group(1).strip(), m.group(2).strip()
        if k.lower() in PARAM_LABELS and k not in out:
            out[k] = v
    return out


def parse_item_page(html: str) -> dict:
    """Описание и продавец со страницы ОДНОГО объявления.

    Порядок разбора описания: блок item-view/item-description → og:description
    → meta description → JSON-LD. Первое, что дало ≥ 20 символов, и берём.
    """
    raw = str(html or '')
    desc = text_from_marker(raw, 'item-view/item-description')
    if len(desc) < 20:
        for alt in (_meta_content(raw, 'og:description'),
                    _meta_content(raw, 'description'),
                    _jsonld_description(raw)):
            alt = re.sub(r'\s+', ' ', str(alt or '')).strip()
            if len(alt) >= 20:
                desc = alt
                break
    desc = desc.strip()[:DESC_MAX_CHARS]
    seller = parse_item_seller(raw)
    # Характеристики — главный источник для отбора: состояние, размер, бренд.
    params = parse_item_params(raw)
    low = {k.lower(): v for k, v in params.items()}
    return {
        'description': desc,
        'seller_type': seller['seller_type'],
        'seller_name': seller['seller_name'],
        'seller_ads': seller['seller_ads'],
        'params': params,
        'condition': low.get('состояние', ''),
        'size': low.get('размер') or low.get('размер одежды') or low.get('размер обуви') or '',
    }


def parse_page(html: str) -> list:
    """Пробуем три способа по очереди и берём тот, что дал больше карточек."""
    # Микроразметка первая: проверено, что на живой выдаче Авито JSON-LD нет,
    # а данные лежат именно в itemProp
    results = [items_from_microdata(html), items_from_jsonld(html),
               items_from_initial_data(html), items_from_html(html)]
    best = max(results, key=len) if results else []
    # Чистим: без цены и без ссылки карточка бесполезна
    clean, seen = [], set()
    for item in best:
        if not item.get('title') or not item.get('price') or not item.get('url'):
            continue
        key = item.get('external_id') or item['url']
        if key in seen:
            continue
        seen.add(key)
        clean.append(item)
    return clean


# ── Отправка на сервер ──────────────────────────────────────────────────────
def push(server: str, token: str, source: str, items: list) -> dict:
    """Отправка находок на сервер.

    Идёт через curl_cffi: у системного Python на macOS нет корневых
    сертификатов, и обычный urllib падал с CERTIFICATE_VERIFY_FAILED — из-за
    этого находки собирались, но НЕ доходили до сервера и до бота.
    """
    url = f"{server.rstrip('/')}/api/ingest"
    # Партию режем на порции. Раньше всё накопленное уходило ОДНИМ запросом:
    # на живой базе такой запрос занимал до 19.8 секунды, и всё это время
    # сервер не отвечал — приложение «зависало». Порция 400 карточек
    # обрабатывается за десятые доли секунды.
    CHUNK = 400
    if len(items) > CHUNK:
        total = {'accepted': 0, 'duplicate': 0, 'skipped': 0, 'ids': [], 'need_details': []}
        for start in range(0, len(items), CHUNK):
            part = push(server, token, source, items[start:start + CHUNK])
            for key in ('accepted', 'duplicate', 'skipped'):
                total[key] += int(part.get(key) or 0)
            total['ids'].extend(part.get('ids') or [])
            total['need_details'].extend(part.get('need_details') or [])
            time.sleep(1.0)
        return total
    body = json.dumps({'source': source, 'items': items}).encode()
    headers = {'Content-Type': 'application/json', 'X-Ingest-Token': token}
    if _cffi is not None:
        r = _cffi.post(url, data=body, headers=headers, timeout=60)
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:140]}")
        return json.loads(r.text)
    req = urllib.request.Request(url, data=body, headers=headers)
    with _opener().open(req, timeout=60) as resp:
        return json.loads(resp.read().decode())


# Загрузка критериев у сервера. На старте он занят — считает медианы
# и греет картинки, — и за 30 секунд не отвечал. Из-за этого сбор
# шёл по общим страницам, а не по критериям.
def fetch_json(url: str, token: str, timeout: int = 20) -> dict:
    """GET с токеном. Идёт через curl_cffi: у системного Python на macOS
    нет корневых сертификатов, и любой https-запрос падал с
    CERTIFICATE_VERIFY_FAILED. curl_cffi проверяет сертификаты сам."""
    if _cffi is not None:
        r = _cffi.get(url, headers={'X-Ingest-Token': token}, timeout=timeout)
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:140]}")
        return json.loads(r.text)
    req = urllib.request.Request(url, headers={'X-Ingest-Token': token})
    with _opener().open(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def post_json(url: str, token: str, payload: dict, timeout: int = 60) -> dict:
    """POST с токеном. Тоже через curl_cffi — по той же причине."""
    body = json.dumps(payload).encode()
    if _cffi is not None:
        r = _cffi.post(url, data=body, timeout=timeout, headers={
            'Content-Type': 'application/json', 'X-Ingest-Token': token})
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:140]}")
        return json.loads(r.text)
    req = urllib.request.Request(url, data=body, headers={
        'Content-Type': 'application/json', 'X-Ingest-Token': token})
    with _opener().open(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


CITY_SLUG = {
    'Ижевск': 'izhevsk', 'Воткинск': 'votkinsk', 'Сарапул': 'sarapul',
    'Глазов': 'glazov', 'Можга': 'mozhga',
}


# Слово из запроса → категория Авито (родной слаг сайта).
#
# Зачем: «?q=запрос» Авито блокирует, поэтому раньше критерии НЕ влияли на
# сбор — качались все телефоны подряд, а нужное отсеивалось уже на сервере.
# Если подходящий айфон лежал на пятой странице, его просто не находили.
# Теперь запрос переводится в категорию + цену, и фильтрует САМ Авито.
# Русские слова товаров → раздел Авито. Нужно, когда в критерии нет
# категории: без этого сборщик идёт по всему Авито (/all) и тащит шапки
# вместо джинсов.
# Бренды → раздел: критерий часто называют одним брендом («Levis»),
# и без этого он ищется по всему Авито.
BRAND_CATEGORY = {
    'levis': 'odezhda_obuv_aksessuary', 'levi': 'odezhda_obuv_aksessuary',
    'nike': 'odezhda_obuv_aksessuary', 'adidas': 'odezhda_obuv_aksessuary',
    'zara': 'odezhda_obuv_aksessuary', 'uniqlo': 'odezhda_obuv_aksessuary',
    'lacoste': 'odezhda_obuv_aksessuary', 'stone': 'odezhda_obuv_aksessuary',
    'supreme': 'odezhda_obuv_aksessuary', 'carhartt': 'odezhda_obuv_aksessuary',
    'apple': 'telefony', 'samsung': 'telefony', 'xiaomi': 'telefony',
    'iphone': 'telefony', 'macbook': 'noutbuki', 'sony': 'audio_i_video',
}


# Узкие подразделы Авито: если слово запроса известно, берём подкатегорию,
# а не весь раздел. Карточек в разы меньше — модель проверяет меньше и
# тратит меньше токенов. Путь проверен на живом сайте.
# Внимание: узкие подразделы Авито отдают 439 (блок) с серверного IP —
# проверено на живом сайте 29.10.2026: /all/odezhda_obuv_aksessuary работает,
# а /all/odezhda_obuv_aksessuary/muzhskaya_odezhda/kurtki — уже блок. Поэтому
# по умолчанию берём раздел целиком, а точность обеспечивает сервер
# (слова в заголовке, категория, цена). Включается POLKA_NARROW=1.
NARROW_PATHS = {
    'футболка': 'muzhskaya_odezhda/kofty_i_futbolki',
    'футболки': 'muzhskaya_odezhda/kofty_i_futbolki',
    'кофта': 'muzhskaya_odezhda/kofty_i_futbolki',
    'худи': 'muzhskaya_odezhda/kofty_i_futbolki',
    'свитшот': 'muzhskaya_odezhda/kofty_i_futbolki',
    'джинсы': 'muzhskaya_odezhda/dzhinsy',
    'куртка': 'muzhskaya_odezhda/kurtki',
    'пуховик': 'muzhskaya_odezhda/kurtki',
    'пальто': 'muzhskaya_odezhda/palto_i_trenchi',
    'рубашка': 'muzhskaya_odezhda/rubashki',
    'шорты': 'muzhskaya_odezhda/shorty',
    'кроссовки': 'obuv/krossovki',
    'ботинки': 'obuv/botinki',
    'туфли': 'obuv/tufli',
    'сумка': 'aksessuary_i_aksessuary_odezhda/sumki',
}

RU_CATEGORY_WORDS = {
    'джинсы': 'odezhda_obuv_aksessuary', 'джинсов': 'odezhda_obuv_aksessuary',
    'худи': 'odezhda_obuv_aksessuary', 'шапка': 'odezhda_obuv_aksessuary',
    'куртка': 'odezhda_obuv_aksessuary', 'пуховик': 'odezhda_obuv_aksessuary',
    'кофта': 'odezhda_obuv_aksessuary', 'футболка': 'odezhda_obuv_aksessuary',
    'кроссовки': 'odezhda_obuv_aksessuary', 'ботинки': 'odezhda_obuv_aksessuary',
    'сумка': 'odezhda_obuv_aksessuary', 'ремень': 'odezhda_obuv_aksessuary',
    'телефон': 'telefony', 'айфон': 'telefony', 'iphone': 'telefony',
    'ноутбук': 'noutbuki', 'макбук': 'noutbuki', 'macbook': 'noutbuki',
    'наушники': 'audio_i_video', 'колонка': 'audio_i_video',
    'приставка': 'audio_i_video', 'планшет': 'planshety_i_elektronnye_knigi',
    'монитор': 'tovary_dlya_kompyutera', 'клавиатура': 'tovary_dlya_kompyutera',
}


CATEGORY_BY_WORD = {
    # телефоны
    'айфон': 'telefony', 'iphone': 'telefony', 'самсунг': 'telefony',
    'samsung': 'telefony', 'телефон': 'telefony', 'смартфон': 'telefony',
    'xiaomi': 'telefony', 'redmi': 'telefony', 'pixel': 'telefony',
    'huawei': 'telefony', 'realme': 'telefony', 'honor': 'telefony',
    # ноутбуки
    'ноутбук': 'noutbuki', 'macbook': 'noutbuki', 'макбук': 'noutbuki',
    'lenovo': 'noutbuki', 'acer': 'noutbuki', 'asus': 'noutbuki',
    'hp': 'noutbuki', 'dell': 'noutbuki', 'msi': 'noutbuki',
    # планшеты
    'планшет': 'planshety_i_elektronnye_knigi', 'ipad': 'planshety_i_elektronnye_knigi',
    # приставки и игры
    'приставка': 'igry_pristavki_i_programmy', 'playstation': 'igry_pristavki_i_programmy',
    'xbox': 'igry_pristavki_i_programmy', 'nintendo': 'igry_pristavki_i_programmy',
    # аудио и видео
    'наушники': 'audio_i_video', 'airpods': 'audio_i_video', 'колонка': 'audio_i_video',
    'телевизор': 'audio_i_video', 'телек': 'audio_i_video', 'саундбар': 'audio_i_video',
    # бытовая техника
    'холодильник': 'bytovaya_tehnika', 'стиральная': 'bytovaya_tehnika',
    'пылесос': 'bytovaya_tehnika', 'микроволновка': 'bytovaya_tehnika',
    # комплектующие
    'монитор': 'tovary_dlya_kompyutera', 'клавиатура': 'tovary_dlya_kompyutera',
    'видеокарта': 'tovary_dlya_kompyutera', 'мышь': 'tovary_dlya_kompyutera',
    # одежда и обувь
    'куртка': 'odezhda_obuv_aksessuary', 'пуховик': 'odezhda_obuv_aksessuary',
    'кроссовки': 'odezhda_obuv_aksessuary', 'ботинки': 'odezhda_obuv_aksessuary',
    'сапоги': 'odezhda_obuv_aksessuary', 'платье': 'odezhda_obuv_aksessuary',
    'сумка': 'odezhda_obuv_aksessuary', 'джинсы': 'odezhda_obuv_aksessuary',
    'худи': 'odezhda_obuv_aksessuary', 'футболка': 'odezhda_obuv_aksessuary',
    # одежда и обувь: слова, которых не хватало — из-за них критерии вроде
    # «Зип кофта мальчика 158» не искались ВООБЩЕ (категория не узнавалась)
    'кофта': 'odezhda_obuv_aksessuary', 'свитер': 'odezhda_obuv_aksessuary',
    'джемпер': 'odezhda_obuv_aksessuary', 'толстовка': 'odezhda_obuv_aksessuary',
    'лонгслив': 'odezhda_obuv_aksessuary', 'рубашка': 'odezhda_obuv_aksessuary',
    'брюки': 'odezhda_obuv_aksessuary', 'шорты': 'odezhda_obuv_aksessuary',
    'пальто': 'odezhda_obuv_aksessuary', 'кардиган': 'odezhda_obuv_aksessuary',
    'ветровка': 'odezhda_obuv_aksessuary', 'дубленка': 'odezhda_obuv_aksessuary',
    'шапка': 'odezhda_obuv_aksessuary', 'шарф': 'odezhda_obuv_aksessuary',
    'перчатки': 'odezhda_obuv_aksessuary', 'туфли': 'odezhda_obuv_aksessuary',
    'сандалии': 'odezhda_obuv_aksessuary', 'рюкзак': 'odezhda_obuv_aksessuary',
    'часы': 'odezhda_obuv_aksessuary', 'очки': 'odezhda_obuv_aksessuary',
    # бренды одежды и обуви — их пишут в критерии вместо слова «куртка»
    'nike': 'odezhda_obuv_aksessuary', 'adidas': 'odezhda_obuv_aksessuary',
    'puma': 'odezhda_obuv_aksessuary', 'zara': 'odezhda_obuv_aksessuary',
    'lacoste': 'odezhda_obuv_aksessuary', 'columbia': 'odezhda_obuv_aksessuary',
    'salomon': 'odezhda_obuv_aksessuary', 'timberland': 'odezhda_obuv_aksessuary',
    'bape': 'odezhda_obuv_aksessuary', 'ugg': 'odezhda_obuv_aksessuary',
    'alpha': 'odezhda_obuv_aksessuary', 'the north face': 'odezhda_obuv_aksessuary',
    'stone island': 'odezhda_obuv_aksessuary', 'uniqlo': 'odezhda_obuv_aksessuary',
    # прочее
    'велосипед': 'velosipedy', 'гитара': 'muzykalnye_instrumenty',
    'квартира': 'kvartiry', 'автомобиль': 'avtomobili', 'машина': 'avtomobili',
    # инструменты, спорт, красота, авто-запчасти и прочее
    'перфоратор': 'instrumenty', 'шуруповёрт': 'instrumenty', 'шуруповерт': 'instrumenty',
    'дрель': 'instrumenty', 'болгарка': 'instrumenty', 'компрессор': 'instrumenty',
    'гантели': 'sport_i_otdyh', 'дорожка': 'sport_i_otdyh', 'тренажёр': 'sport_i_otdyh',
    'фен': 'krasota_i_zdorovie', 'эпилятор': 'krasota_i_zdorovie', 'массажёр': 'krasota_i_zdorovie',
    'шины': 'zapchasti_i_aksessuary', 'диски': 'zapchasti_i_aksessuary',
    'ssd': 'tovary_dlya_kompyutera', 'процессор': 'tovary_dlya_kompyutera',
    'alpha': 'odezhda_obuv_aksessuary', 'industries': 'odezhda_obuv_aksessuary',
    'stone': 'odezhda_obuv_aksessuary', 'island': 'odezhda_obuv_aksessuary',
    'canada': 'odezhda_obuv_aksessuary', 'goose': 'odezhda_obuv_aksessuary',
    'north': 'odezhda_obuv_aksessuary', 'patagonia': 'odezhda_obuv_aksessuary',
    'moncler': 'odezhda_obuv_aksessuary', 'uniqlo': 'odezhda_obuv_aksessuary',
    'infinix': 'telefony', 'oppo': 'telefony', 'vivo': 'telefony',
    'tecno': 'telefony', 'nothing': 'telefony', 'чехол': 'telefony',
    'компьютер': 'tovary_dlya_kompyutera', 'пк': 'tovary_dlya_kompyutera',
    'системный': 'tovary_dlya_kompyutera', 'keychron': 'tovary_dlya_kompyutera',
    'nuphy': 'tovary_dlya_kompyutera', 'процессор': 'tovary_dlya_kompyutera',
    'диван': 'mebel', 'стол': 'mebel', 'стул': 'mebel', 'шкаф': 'mebel',
    'книга': 'knigi_i_zhurnaly', 'самокат': 'velosipedy',
    'кровать': 'mebel', 'комод': 'mebel', 'матрас': 'mebel',
}


# Шаблон ссылки поиска. Задан по умолчанию, но его можно переопределить
# в config.json ("url_template": "…") или переменной POLKA_URL_TEMPLATE —
# не трогая код. Зачем: форму ссылки и фильтры Авито надёжнее всего взять
# из браузера (поиск → нужные фильтры → скопировать адрес из строки).
# Подстановки: {category} {query} {pmin} {pmax} {page}
# ПРОВЕРЕНО 15.10.2026 на живом сайте (ссылка владельца из браузера):
#   /all/odezhda_obuv_aksessuary?cd=1&localPriority=0&q=пуховик&user=1&s=104
# даёт 75–81 карточку ровно по запросу. Разница с прежними попытками —
# параметры cd=1, user=1 и localPriority=0: без них Авито отбивал запрос
# (429/439), и я решил, что поиск недоступен. Он доступен.
#   q={query}  — слова критерия, ищет сам Авито (точность вместо перебора)
#   user=1     — только частные объявления (фильтр продавца со стороны Авито)
#   cd=1       — как в браузерной ссылке, без него не работает
#   {filters}  — необязательный набор фильтров (f=...) из ссылки браузера:
#                состояние, доставка, память. Задаётся в config.json.
# Проверено на живом сайте с резидентским прокси 30.10.2026:
# «?q=&s=&pmax=» отдаёт 80+ карточек, а тот же адрес с cd/localPriority/
# user/f= получает 439. Лишние параметры — верный признак бота для WAF.
DEFAULT_URL_TEMPLATE = ("https://www.avito.ru/all/{category}"
                        "?q={query}&s=104&pmin={pmin}&pmax={pmax}")


def search_url(template: str, slug: str, query: str, pmin: int, pmax: int,
               filters: str = '', user: str = '1') -> str:
    """Собирает ссылку поиска по шаблону и убирает пустые параметры.

    Пустые pmin/pmax и отсутствие категории не должны оставлять в ссылке
    «хвосты» вида «&pmin=&pmax=» или «/all/»: Авито на такое отвечает
    ошибкой, а не пустой выдачей.
    """
    url = str(template or DEFAULT_URL_TEMPLATE)
    for key, value in (('{category}', slug or ''),
                       ('{query}', quote_plus(query or '')),
                       ('{user}', user or ''),
                       ('{filters}', str(filters or '')),
                       ('{pmin}', str(int(pmin)) if pmin else ''),
                       ('{pmax}', str(int(pmax)) if pmax else '')):
        url = url.replace(key, value)
    # Категории нет → путь /all/, превращаем в /all
    url = url.replace('/all/?', '/all?').replace('/all/&', '/all&')
    url = re.sub(r'[?&](pmin|pmax|user|q)=(?=&|$)', '', url)
    url = url.replace('?&', '?').replace('&&', '&')
    if url.endswith('/all/'):
        url = url[:-1]
    return url.rstrip('?&')


# Разделы, которые Авито придерживает: вместо них берём соседний и
# добавляем слово для локального отбора.
CATEGORY_SUBSTITUTE = {
    'noutbuki': 'tovary_dlya_kompyutera',
    'nastolnye_kompyutery': 'tovary_dlya_kompyutera',
}
CATEGORY_SUBSTITUTE_WORD = {
    'noutbuki': 'ноутбук',
    'nastolnye_kompyutery': 'компьютер',
}


def category_url_from(url: str) -> str:
    """Обычный раздел Авито из ссылки с фильтрами.

    …/all/noutbuki/noutbuki/apple/do50-ASgB… → https://www.avito.ru/all/noutbuki

    Берём сегмент СРАЗУ после «all» — это всегда раздел площадки. Раньше
    искали первое совпадение по списку категорий, и для ноутбуков находилось
    «telefony» из соседнего сегмента: сборщик ходил не в тот раздел.
    """
    try:
        path = urllib.parse.urlparse(url).path
    except Exception:
        return ''
    parts = [p for p in path.split('/') if p]
    slug = ''
    if 'all' in parts:
        idx = parts.index('all')
        if idx + 1 < len(parts):
            slug = parts[idx + 1].split('-')[0]
    elif len(parts) >= 2:
        # Ссылка с регионом: moskva/telefony/apple/... → «moskva/telefony»
        slug = f"{parts[0]}/{parts[1].split('-')[0]}"
    if not slug:
        # запасной путь: первый сегмент, который знаем как категорию
        for part in parts:
            base = part.split('-')[0]
            if base in list(CATEGORY_BY_WORD.values()):
                slug = base
                break
    if not slug:
        return ''
    # Некоторые разделы Авито отдаёт только с блокировкой (проверено:
    # /all/noutbuki стабильно 439, а /all/tovary_dlya_kompyutera — 200).
    # Для них берём соседний раздел и фильтруем по слову.
    # Регион уже в пути (moskva/telefony) — не добавляем /all
    if '/' in slug:
        return f"https://www.avito.ru/{slug}?s=104"
    slug = CATEGORY_SUBSTITUTE.get(slug, slug)
    return f"https://www.avito.ru/all/{slug}?s=104"


def local_filters_from_url(url: str) -> dict:
    """Что забрать из ссылки для локальной фильтрации: цену и модель."""
    out = {'price_to': 0, 'price_from': 0, 'words': []}
    try:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    except Exception:
        q = {}
    blob = (q.get('f') or [''])[0]
    for m in re.finditer(r'eyJ[A-Za-z0-9_-]{8,}', blob or ''):
        raw = m.group(0)
        try:
            pad = raw + '=' * (-len(raw) % 4)
            dec = base64.urlsafe_b64decode(
                pad.replace('-', '+').replace('_', '/')).decode('utf-8', 'ignore')
        except Exception:
            continue
        for chunk in re.findall(r'\{[^{}]*\}', dec):
            try:
                data = json.loads(chunk)
            except Exception:
                continue
            frm, to = data.get('from'), data.get('to')
            if isinstance(to, int) and to >= 1000 and not out['price_to']:
                out['price_to'] = to
            elif isinstance(frm, int) and frm >= 1000 and not out['price_from']:
                out['price_from'] = frm
    # модель из пути: …/apple/do50-ASgB… → «do50»
    try:
        path = urllib.parse.urlparse(url).path
        for part in reversed([p for p in path.split('/') if p]):
            base = part.split('-')[0].replace('_', ' ').strip().lower()
            if base and base not in list(CATEGORY_BY_WORD.values()) and not base.isdigit():
                out['words'] = [w for w in base.split() if len(w) > 1]
                break
    except Exception:
        pass
    return out


def matches_local(ad: dict, flt: dict) -> bool:
    """Проходит ли объявление фильтры, снятые со ссылки."""
    if not flt:
        return True
    price = int(ad.get('price') or 0)
    if flt.get('price_to') and price and price > flt['price_to']:
        return False
    if flt.get('price_from') and price and price < flt['price_from']:
        return False
    words = flt.get('words') or []
    if words:
        title = str(ad.get('title') or '').lower()
        if not all(w in title for w in words):
            return False
    return True


# Критерий из ссылки Авито: путь, фильтры и продавец берём как есть (после проверки),
# q только из самой ссылки: название критерия не должно сужать выдачу.
LINK_PATH_RE = re.compile(r'^[A-Za-z0-9_\-]+(?:/[A-Za-z0-9_\-]+){0,5}$')
LINK_FILTERS_RE = re.compile(r'^(?:&[A-Za-z0-9_\[\]]+=[A-Za-z0-9_%.,:+\-]*)*$')

def link_search_url(crit: dict, cfg: dict = None) -> str:
    """Ссылка поиска для критерия, созданного из ссылки Авито. Пусто, если данные
    не проходят проверку (тогда цель не создаётся: лучше пропустить, чем искать не то)."""
    path = str(crit.get('search_path') or '').strip().strip('/')
    if not LINK_PATH_RE.match(path):
        return ''
    # Глубокие пути (регион/раздел/подраздел/модель) Авито отдаёт только
    # браузеру и отвечает 439. Обрезаем до «регион/раздел»: там выдача шире,
    # но доступна, а модель и цену отсеиваем сами.
    segs = path.split('/')
    if len(segs) > 2:
        path = '/'.join(segs[:2])
    # Городской путь (/izhevsk/...) Авито отдаёт только браузеру и отвечает
    # 439 с серверного IP и через прокси. Заменяем город на «all»: выдача
    # шире, зато доступна, а город и цену отсеиваем сами.
    if len(segs) >= 2 and segs[0] not in ('all', 'rossiya'):
        path = 'all/' + segs[1]
    filters = str(crit.get('filters') or '')
    if len(filters) > 1500 or not LINK_FILTERS_RE.match(filters):
        return ''
    try:
        pmin = int(crit.get('min_price') or 0)
    except Exception:
        pmin = 0
    try:
        pmax = int(crit.get('max_price') or 0)
    except Exception:
        pmax = 0
    user = str(crit.get('user') or '')
    if user not in ('', '1', '2'):
        user = ''
    # Ссылку строим заново и «чисто»: cd/localPriority/user и f= Авито
    # считает признаком бота и отвечает 439 даже через резидентский прокси.
    # Оставляем путь раздела, слова запроса из ссылки, сортировку и цену.
    query = " ".join(str(crit.get('search_q') or crit.get('query') or '').split())[:80]
    # С q= Авито отвечает 439 почти всегда, поэтому по умолчанию открываем
    # раздел. Слова применяет сервер при отборе.
    template = ("https://www.avito.ru/{path}?q={query}&s=104&pmin={pmin}&pmax={pmax}"
                if SEARCH_BY_QUERY else
                "https://www.avito.ru/{path}?s=104&pmin={pmin}&pmax={pmax}")
    url = (template.replace('{path}', path)
           .replace('{query}', quote_plus(query))
           .replace('{pmin}', str(pmin) if pmin else '')
           .replace('{pmax}', str(pmax) if pmax else ''))
    url = re.sub(r'[?&](pmin|pmax|q)=(?=&|$)', '', url)
    return url.replace('?&', '?').replace('&&', '&').rstrip('?&')


def user_targets(server: str, token: str, cfg: dict = None) -> dict:
    """Цели по критериям, сгруппированные по ПОЛЬЗОВАТЕЛЮ.

    Зачем: лоты должны приносить пользу конкретному человеку. Если взять
    просто «все критерии подряд», один активный пользователь занимает
    очередь, а остальные ждут. Здесь каждый получает свою долю проходов.
    """
    try:
        data = fetch_json(f"{server.rstrip('/')}/api/hunt?for_collector=1", token)
    except Exception as exc:
        print(f"  ⚠ критерии не получены: {exc}")
        return {}
    grouped: dict = {}
    # Ограничение: не душим площадку — берём по 1 цели на пользователя
    per_user = int(os.environ.get('POLKA_TARGETS_PER_USER', '1') or 1)
    for crit in (data.get('items') or []):
        uid = str(crit.get('user_id') or '')
        query = " ".join(str(crit.get('query') or '').split())[:80]
        if not query or not uid:
            continue
        words = [w for w in re.split(r'[^\w]+', query.lower()) if w]
        slug = None
        for word in words:
            if word in CATEGORY_BY_WORD:
                slug = CATEGORY_BY_WORD[word]
                break
        if not slug:
            for word in words:
                if word in RU_CATEGORY_WORDS:
                    slug = RU_CATEGORY_WORDS[word]
                    break
        if not slug:
            for word in words:
                if word in BRAND_CATEGORY:
                    slug = BRAND_CATEGORY[word]
                    break
        if not slug:
            continue
        slug = CATEGORY_SUBSTITUTE.get(slug, slug)
        try:
            pmin = int(crit.get('min_price') or 0)
            pmax = int(crit.get('max_price') or 0)
        except Exception:
            pmin, pmax = 0, 0
        url = (f"https://www.avito.ru/all/{slug}"
               + (f"?pmax={pmax}&s=104" if pmax else "?s=104"))
        grouped.setdefault(uid, []).append({
            'url': url, 'city': '', 'category': query,
            'query': query, 'crit_id': crit.get('id'),
        })
    return {u: v[:per_user] for u, v in grouped.items()}


def rotation_batch(server: str, token: str, pass_no: int, limit: int,
                   cfg: dict = None) -> list:
    """Кого проверяем в этом проходе: пользователи идут по кругу.

    pass_no растёт на каждой попытке, поэтому очередь сама переходит от
    одного пользователя к другому — без ручного управления.
    """
    grouped = user_targets(server, token, cfg)
    if not grouped:
        return []
    users = sorted(grouped)
    picked = []
    for i in range(min(limit, len(users))):
        user = users[(pass_no + i) % len(users)]
        picked.extend(grouped[user])
        print(f"  → проверяю поиск пользователя {user[:6]}…: "
              f"{grouped[user][0].get('query', '')[:30]}")
    return picked


def targets_from_criteria(server: str, token: str, cfg: dict = None) -> list:
    """Строит страницы поиска из критериев, которые задали пользователи.

    Главное здесь — параметр q: это САМ ЗАПРОС, который Авито ищет своей
    выдачей. Раньше в ссылке были только категория и цена, поэтому сборщик
    качал ВСЮ категорию (десятки тысяч карточек), а нужное отсеивалось уже
    на сервере. Замер на живом сайте: в ссылке без q из 50 карточек по
    словам «iphone 13» подходили 3 — 94% трафика впустую. И критерии, чьи
    слова не попали в справочник категорий («пуховик lacoste», «зип кофта»),
    не искались ВООБЩЕ: для них цель просто не создавалась.

    Ещё это щадит Авито: один точный запрос вместо перебора категории —
    меньше запросов, реже ловим 429 (Too Many Requests).
    """
    template = (os.environ.get('POLKA_URL_TEMPLATE')
                or (cfg or {}).get('url_template')
                or DEFAULT_URL_TEMPLATE)
    try:
        data = fetch_json(f"{server.rstrip('/')}/api/hunt?for_collector=1", token)
    except Exception as exc:
        print(f"  ⚠ критерии не получены: {exc}")
        return []
    targets = []
    seen = set()
    built = 0
    no_query = 0
    no_slug = 0
    for crit in data.get('items', []):
        query = " ".join(str(crit.get('query') or '').split())[:80]
        if not query:
            no_query += 1
            continue
        # Разбиваем и по дефису: «робот-пылесос» должен найтись словом «пылесос»
        words = [w for w in re.split(r'[^\w]+', query.lower()) if w]
        slug = None
        for word in words:
            if word in CATEGORY_BY_WORD:
                slug = CATEGORY_BY_WORD[word]
                break
        if not slug:
            # Слова нет в справочнике Авито — пробуем русский словарь товаров.
            # Без этого «джинсы levis» шло по всему Авито и приносило шапки.
            for word in words:
                if word in RU_CATEGORY_WORDS:
                    slug = RU_CATEGORY_WORDS[word]
                    break
            if not slug:
                for word in words:
                    if word in BRAND_CATEGORY:
                        slug = BRAND_CATEGORY[word]
                        break
        try:
            pmin = int(crit.get('min_price') or 0)
        except Exception:
            pmin = 0
        try:
            pmax = int(crit.get('max_price') or 0)
        except Exception:
            pmax = 0
        if SEARCH_BY_QUERY:
            template_here = template
        else:
            # Проверенный рабочий вид: раздел + сортировка по дате + цена.
            # Точность обеспечивает сервер: он отсеивает по словам заголовка,
            # категории, городу и цене (этапы B и F).
            template_here = "https://www.avito.ru/all/{category}?s=104&pmin={pmin}&pmax={pmax}"
        if slug:
            # Раздел под блокировкой заменяем на соседний (noutbuki → компьютеры)
            slug = CATEGORY_SUBSTITUTE.get(slug, slug)
            # Узкий подраздел — только по явному включению: на серверном IP
            # Авито отдаёт по ним 439, и сбор по критериям (одежда, обувь)
            # не приносил вообще ничего, кроме телефонов.
            if os.environ.get('POLKA_NARROW', '0') == '1':
                for word in words:
                    if word in NARROW_PATHS:
                        slug = slug + '/' + NARROW_PATHS[word]
                        break
        if not slug:
            # Категория не узнана: цель всё равно создаём (поиск по площадке),
            # но считаем такие критерии — по ним раздел не определён.
            no_slug += 1
        # Фильтры Авито (только частные, состояние, АКБ, слова в описании)
        # живут в параметре f=…, который генерирует браузер. Наборы задаются
        # в config.json: {"filters_by_category": {"odezhda_obuv_aksessuary": "&f=…"}}
        # Общий набор — "filters" или POLKA_FILTERS.
        # Набор может прийти от СЕРВЕРА вместе с критерием — тогда ни файлы,
        # ни переменные окружения не нужны (так его и добавляют на будущее:
        # одна ссылка из браузера на категорию).
        # f= — набор фильтров из браузера. С ним Авито отвечает 439 даже
        # через резидентский прокси, поэтому по умолчанию не используем.
        # Включается POLKA_USE_F=1, если понадобятся фильтры площадки.
        server_filters = ''
        if os.environ.get('POLKA_USE_F') == '1':
            server_filters = str(crit.get('filters') or '')
        # Если критерий создан из ссылки человека — открываем ИМЕННО ЕЁ.
        # Раньше адрес собирался заново из слов критерия: получался другой
        # запрос, и приходили не те объявления, что человек видел на Авито.
        # Критерий из ссылки Авито: путь, q и фильтры берем из ссылки как есть.
        link_url = link_search_url(crit)
        if link_url:
            if link_url in seen:
                continue
            seen.add(link_url)
            _q_words = [w for w in str(crit.get('search_q') or '').lower().split() if len(w) > 2]
            targets.append({'url': link_url,
                            'category': crit.get('category') or '',
                            'query': query, 'page': 1, 'direct': True,
                            'link': True,
                            'local': [{'price_to': int(crit.get('max_price') or 0),
                                       'price_from': int(crit.get('min_price') or 0),
                                       'words': _q_words[:2]}]})
            built += 1
            continue
        # У аксессуаров нет аккумулятора и их не «вскрывают»: фильтр товара
        # («АКБ от 80%», «не вскрывался») обнулил бы выдачу — не применяем.
        if any(w in str(crit.get('query') or '').lower() for w in (
                'чехол', 'стекло', 'плёнка', 'пленка', 'бампер', 'кабель', 'шнур',
                'зарядка', 'зарядное', 'адаптер', 'переходник', 'ремешок', 'картридж',
                'запчаст', 'держатель', 'подставка', 'крепление')):
            server_filters = ''
        by_cat = dict((cfg or {}).get('filters_by_category') or {})
        # То же самое можно задать переменной окружения (на сервере это проще,
        # чем править config.json): POLKA_FILTERS_BY_CATEGORY='{"telefony":"&f=…"}'
        # Формат БЕЗ кавычек (панель Амверы их не принимает):
        #   POLKA_FILTERS_BY_CATEGORY=odezhda_obuv_aksessuary=&f=ASgB…;telefony=&f=ASgB…
        # Разделитель записей — «;», ключ и значение — по ПЕРВОМУ «=»
        # (внутри набора фильтров тоже есть «=», поэтому не split('=')).
        # Если значение начинается с «{», считаем его JSON — для config.json.
        env_filters = os.environ.get('POLKA_FILTERS_BY_CATEGORY', '').strip()
        if env_filters.startswith('{'):
            try:
                by_cat.update(json.loads(env_filters))
            except Exception as exc:
                print(f"  ⚠ POLKA_FILTERS_BY_CATEGORY (JSON) не разобран: {exc}")
        elif env_filters:
            for pair in env_filters.replace('\n', ';').split(';'):
                pair = pair.strip()
                if not pair or '=' not in pair:
                    continue
                key, value = pair.split('=', 1)
                key = key.strip()
                value = value.strip()
                if key and value:
                    by_cat[key] = value
            if not by_cat:
                print("  ⚠ POLKA_FILTERS_BY_CATEGORY: не разобрана ни одна пара «категория=набор»")
        filters_here = ''
        for key in (slug or '', str(crit.get('category') or '')):
            if key and by_cat.get(key):
                filters_here = str(by_cat[key])
                break
        if not filters_here:
            filters_here = server_filters
        if not filters_here:
            filters_here = str((cfg or {}).get('filters') or os.environ.get('POLKA_FILTERS', ''))
        # Продавец из КРИТЕРИЯ: сервер отдаёт user='1' (только частные) или
        # '' (все). Раньше сборщик принудительно ставил user=1 всем.
        # '1' — частные, '' — все, '2' — компании. Пустую строку от сервера
        # НЕ подменяем (это осознанный «все»), подменяем только отсутствие.
        user_here = str(crit.get('user', '1'))
        url = search_url(template_here, slug or '', query, pmin, pmax,
                         filters=filters_here, user=user_here)
        if url in seen:
            continue
        seen.add(url)
        # Три страницы: со скрапером блокировок нет, а 50 карточек раздела —
        # слишком узкая выборка, нужные лоты в неё не попадают.
        targets.append({'url': url, 'category': crit.get('category') or slug or '',
                        # Одна страница на критерий: три страницы на цель
                        # давали 15 запросов за проход и гарантированный 439.
                        'query': query, 'page': 1,
                        'pages': int(os.environ.get('POLKA_CRITERIA_PAGES', '1') or 1)})
        built += 1
    if built:
        mode = ("Авито ищет по тексту запроса (q=)" if SEARCH_BY_QUERY
                else "раздел Авито + отсев по словам на сервере")
        print(f"  Целей из критериев: {built} — {mode}")
    if no_query:
        print(f"  Критериев без текста: {no_query}")
    if no_slug:
        print(f"  ⚠ Критериев без узнаваемого слова категории: {no_slug} — "
              f"ищутся по всей площадке")
        print("    Точнее будет добавить слово категории (куртка, телефон, ноутбук)")
    return targets


def check_listings(server: str, token: str, limit: int = 30) -> int:
    """Перепроверяет лоты: продано, снято или ещё висит.

    Это и даёт «ушло за 3 часа» — главный ориентир цены для перекупа.
    """
    try:
        data = fetch_json(f"{server.rstrip('/')}/api/ingest/checklist?limit={limit}", token)
    except Exception as exc:
        print(f"  ✖ список не получен: {exc}")
        return 0
    items = data.get('items') or []
    print(f"  проверяем лотов: {len(items)}")
    report, gone = [], 0
    for item in items:
        url = item.get('source_url')
        ext = item.get('external_id')
        if not url or not ext:
            continue
        state = 'active'
        try:
            html = fetch(url, prefer_scraper=('q=' in url))
            low = html.lower()
            if any(marker in low for marker in GONE_MARKERS):
                state = 'gone'
        except Blocked as exc:
            print(f"  ⛔ {exc} — прекращаю проверку")
            break
        except urllib.error.HTTPError as exc:
            # 404 и 410 — страницы больше нет, значит лот снят или продан
            if exc.code in (404, 410):
                state = 'gone'
        except Exception:
            continue
        if state == 'gone':
            gone += 1
        report.append({'external_id': ext, 'state': state})
        time.sleep(random.uniform(2.0, 4.0))
    if report:
        try:
            res = post_json(f"{server.rstrip('/')}/api/ingest/status", token,
                            {'source': data.get('source', 'avito'), 'items': report})
            print(f"  отмечено исчезнувшими: {res.get('gone', gone)} из {len(report)}")
        except Exception as exc:
            print(f"  ✖ статус не отправлен: {exc}")
    return gone


def check_proxy(url: str) -> int:
    """Пускает ли Авито с этого IP. Проверяет несколько адресов подряд.

    Городские страницы (/izhevsk/...) Авито отдаёт реже, чем общие (/all/...),
    поэтому пробуем оба варианта и говорим, какой сработал.
    """
    print(f"Прокси: {PROXY or 'не задан — идём напрямую'}")
    print(f"Клиент: {'curl_cffi, отпечаток ' + IMPERSONATE if _cffi else 'urllib (curl_cffi НЕ установлен!)'}")

    candidates = [url]
    try:
        from urllib.parse import urlsplit, urlunsplit
        sp = urlsplit(url)
        parts = [p for p in sp.path.split('/') if p]
        if len(parts) >= 2 and parts[0] != 'all':
            candidates.append(urlunsplit((sp.scheme, sp.netloc,
                                          '/all/' + parts[1], sp.query, '')))
    except Exception:
        pass
    candidates.append('https://www.avito.ru/all/velosipedy?s=104')

    print("  прогреваю cookies на главной…")
    try:
        warm_up()
    except Exception:
        pass

    html = None
    chosen = ''
    for cand in candidates:
        if 'q=' in cand:
            continue
        print(f"Проверяем: {cand}")
        try:
            page = fetch(cand, prefer_scraper=False)
        except Blocked as exc:
            print(f"  ⛔ {exc}")
            continue
        except Exception as exc:
            print(f"  ✖ не открылось: {str(exc)[:80]}")
            continue
        if page:
            html, chosen = page, cand
            break

    if not html:
        print("  ⛔ все проверенные адреса закрыты.")
        print("  Что это значит:")
        if PROXY:
            print("   • прокси из дата-центра — Авито блокирует такие целиком;")
            print("   • нужен резидентный или мобильный прокси.")
        else:
            print("   • телефон в мобильном интернете, а не в Wi-Fi — включите Wi-Fi;")
            print("   • или этот IP под баном — перезагрузите роутер (IP сменится);")
            print("   • подождите 20–30 минут и попробуйте снова.")
        return 1

    items = parse_page(html)
    print(f"  страница получена: {len(html)} байт ({chosen[:48]})")
    print(f"  карточек разобрано: {len(items)}")
    for it in items[:5]:
        print(f"    {str(it.get('title'))[:44]:<44} {it.get('price')} ₽")
    if not _cffi:
        print("  ⚠ curl_cffi не установлен — Авито будет резать чаще.")
        print("    Установите: pip3 install curl_cffi")
    print("  ✅ Работает: Авито отдаёт выдачу, разбор находит объявления.")
    return 0

def load_config(path: str) -> dict:
    # Файл может отсутствовать: на сервере всё приходит из переменных
    # окружения, а цели берутся из критериев пользователей.
    cfg = {}
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as fh:
                cfg = json.load(fh)
        except Exception as exc:
            print(f"  ⚠ config.json не прочитан: {exc}")
    server = os.environ.get('POLKA_SERVER') or cfg.get('server') or ''
    # Два разных токена: INGEST — отправка находок и описаний,
    # ADMIN_READ — только диагностика. Если токен сборщика утечёт, читать
    # через него админскую диагностику будет нельзя.
    token = os.environ.get('POLKA_INGEST_TOKEN') or cfg.get('token') or ''
    admin_token = (os.environ.get('POLKA_ADMIN_READ_TOKEN')
                   or cfg.get('admin_token') or '')
    if not server or not token:
        sys.exit("Не заданы server и token: заполните config.json "
                 "или переменные POLKA_SERVER и POLKA_INGEST_TOKEN")
    # Токен уходит в HTTP-заголовке, а там допустима только латиница.
    # Кириллический токен иначе падал бы загадочной ошибкой кодировки.
    try:
        token.encode('ascii')
    except UnicodeEncodeError:
        sys.exit("Токен должен состоять только из латинских букв, цифр и "
                 "знаков -_ . Кириллица в заголовок не помещается.\n"
                 "Сгенерируйте новый: openssl rand -base64 32")
    cfg['server'] = server
    cfg['token'] = token              # обратная совместимость: это INGEST
    cfg['ingest_token'] = token
    cfg['admin_token'] = admin_token  # только для диагностики
    cfg.setdefault('targets', [])
    return cfg


def push_details(server: str, token: str, source: str, items: list) -> dict:
    """Отправляет описания и продавцов на сервер: POST /api/ingest/details."""
    url = f"{server.rstrip('/')}/api/ingest/details"
    body = json.dumps({'source': source, 'items': items}).encode()
    headers = {'Content-Type': 'application/json', 'X-Ingest-Token': token}
    if _cffi is not None:
        r = _cffi.post(url, data=body, headers=headers, timeout=90)
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:140]}")
        return json.loads(r.text)
    req = urllib.request.Request(url, data=body, headers=headers)
    with _opener().open(req, timeout=90) as resp:
        return json.loads(resp.read().decode())


def collect_details(server: str, token: str, source: str, items: list,
                    pause: tuple = (4.0, 9.0)) -> int:
    """Открывает карточки кандидатов и присылает описания на сервер.

    Сервер этого сделать не может: он в дата-центре, и Авито его блокирует,
    поэтому страницы объявлений открываем мы — по одной, с паузой 4–9 секунд.

    ВАЖНО про запуск на GitHub Actions: у раннеров адрес дата-центра, и
    страницы объявлений там, скорее всего, не откроются. Это НЕ повод валить
    весь сбор: при блокировке просто пропускаем описания до следующего
    прохода (объявления в базе остаются с пометкой «описание не проверено»)
    и продолжаем собирать выдачу. Пометку failed серверу в этом случае не
    шлём — иначе три неудачных прохода подряд навсегда закроют карточку.
    """
    global _DETAILS_BLOCKED, _DETAILS_BLOCKED_SINCE
    if not items:
        return 0
    if _DETAILS_BLOCKED:
        # Авто-восстановление: после 439 ждём полчаса и пробуем снова,
        # без ручного перезапуска. Один запрос за 30 минут не жечёт лимит.
        if _DETAILS_BLOCKED_SINCE and (time.time() - _DETAILS_BLOCKED_SINCE) < DETAILS_BLOCK_RETRY_SEC:
            return 0
        _DETAILS_BLOCKED = False
        _DETAILS_BLOCKED_SINCE = 0.0
        print("  …переждали 30 минут — пробую снова (блок мог сняться)")
    out = []
    for i, item in enumerate(items):
        url = str(item.get('url') or '')
        ext = str(item.get('external_id') or '')
        if not url.startswith('http'):
            continue
        try:
            html = fetch_item(url)
        except Blocked as exc:
            _DETAILS_BLOCKED = True
            _DETAILS_BLOCKED_SINCE = time.time()
            print(f"  ⛔ описания недоступны с этого IP: {exc}")
            print(f"    пережду {int(DETAILS_BLOCK_RETRY_SEC // 60)} минут и попробую снова сам")
            print("    Скорее всего это дата-центр (GitHub Actions). Соберите")
            print("    описания с домашнего компьютера: collector/start-local.sh")
            if out:
                try:
                    push_details(server, token, source, out)
                except Exception as exc2:
                    print(f"  ✖ сервер не принял описания: {exc2}")
            return len(out)
        except Exception as exc:
            print(f"  ✖ описание не открылось: {exc}")
            out.append({'external_id': ext, 'state': 'failed'})
            continue
        data = parse_item_page(html)
        if len(data.get('description') or '') < 20:
            print(f"  ⚠ описание пустое ({url[-32:]})")
            out.append({'external_id': ext, 'state': 'failed'})
        else:
            # Характеристики (состояние, память, размер) — из блока
            # параметров карточки. Раньше их достали, но не передавали.
            try:
                params = parse_item_params(html)
            except Exception:
                params = {}
            out.append({'external_id': ext, 'state': 'ok',
                        'description': data['description'],
                        'params': params,
                        'seller_type': data['seller_type'],
                        'seller_name': data['seller_name'],
                        'seller_ads': int(data['seller_ads'] or 0)})
            who = ('магазин' if data['seller_type'] == 'company'
                   else 'частник' if data['seller_type'] == 'private' else 'продавец не определён')
            print(f"  ✓ описание {len(data['description'])} симв., {who}")
        # Пауза между страницами: Авито ограничивает частые запросы
        if i < len(items) - 1:
            time.sleep(random.uniform(*pause))
    if out:
        try:
            stats = push_details(server, token, source, out)
            print(f"  описаний отправлено: {stats.get('updated')}, неудач {stats.get('failed')}")
        except Exception as exc:
            print(f"  ✖ сервер не принял описания: {exc}")
    return len(out)


def target_urls(target: dict, cfg: dict) -> list:
    """Ссылки одной цели: страницы 1..pages и необязательные pmin/pmax.

    Этап D10. По умолчанию pages=1: обход лишних страниц — это лишние
    запросы к Авито, и включать его нужно осознанно (в config.json у цели:
    "pages": 2, "pmin": 5000, "pmax": 60000). Условия проверять на живом
    сайте: разметка страниц и параметры цены могут отличаться.
    """
    url = str(target.get('url') or '')
    if not url.startswith('http'):
        return []
    pages = int(target.get('pages') or cfg.get('pages') or 1)
    pages = max(1, min(pages, 3))
    pmin = target.get('pmin') or cfg.get('pmin') or 0
    pmax = target.get('pmax') or cfg.get('pmax') or 0
    extra = []
    if pmin:
        extra.append(f"pmin={int(pmin)}")
    if pmax:
        extra.append(f"pmax={int(pmax)}")
    urls = []
    for page in range(1, pages + 1):
        parts = list(extra)
        if page > 1:
            parts.append(f"p={page}")
        if not parts:
            urls.append(url)
            continue
        joiner = '&' if '?' in url else '?'
        urls.append(url + joiner + '&'.join(parts))
    return urls


def date_sorted_first_page(url: str) -> bool:
    """Выдача отсортирована по дате и это первая страница?

    Отсюда берётся право считать «впервые увиденное» свежим: Авито отдаёт
    сначала самые новые объявления (этап D5).
    """
    text = str(url or '')
    return 's=104' in text and ('p=' not in text)


# Сколько целей обходим за один проход. Целей может быть больше сотни, и
# обойти все разом нельзя: Авито ограничивает частоту, а проход становится
# бесконечным. Остальные подхватит следующий проход — очередь вращается.
MAX_TARGETS = int(os.environ.get('POLKA_MAX_TARGETS', '40'))
# Пауза между страницами разных критериев: меньше блокировок
TARGET_PAUSE = int(os.environ.get('POLKA_TARGET_PAUSE', '20'))
# Как часто можно проверять ОДИН поиск: по умолчанию раз в час
CHECK_INTERVAL_MIN = int(os.environ.get('POLKA_CHECK_INTERVAL_MIN', '60'))
# Как часто «прогреваться» на главной Авито (в проходах)
WARM_UP_EVERY = int(os.environ.get('POLKA_WARM_UP_EVERY', '2'))
# Сколько карточек открывать за проход ради описания и продавца.
# Каждая карточка — отдельный запрос, поэтому немного.
DETAILS_PER_PASS = int(os.environ.get('POLKA_DETAILS_PER_PASS', '3'))
TARGETS_STATE_FILE = os.environ.get('POLKA_TARGETS_STATE', 'targets_state.json')


def _targets_state_path() -> str:
    """Файл состояния рядом со сборщиком (не в конфиге: это не настройка)."""
    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, TARGETS_STATE_FILE)


def load_targets_state() -> dict:
    try:
        with open(_targets_state_path(), encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_targets_state(state: dict) -> None:
    try:
        with open(_targets_state_path(), 'w', encoding='utf-8') as fh:
            json.dump(state, fh, ensure_ascii=False, indent=1)
    except Exception as exc:
        print(f"  ⚠ состояние целей не сохранилось: {exc}")


def _today() -> str:
    return time.strftime('%Y-%m-%d')


def target_sort_key(target: dict, state: dict, day: str):
    """Ключ порядка целей: кто приносит находки — вперёд, остальные в конец.

    Правила по приоритету:
      1. цели, где в прошлый раз были находки — первыми (живой спрос);
      2. ещё не проверенные сегодня — раньше проверенных (ротация);
      3. самые давние по времени — раньше (чтобы очередь не застаивалась).
    «Редкие» критерии (находок не было ни разу) естественно уезжают в конец
    и проверяются реже — но всё равно проверяются, за счёт ротации.
    """
    st = state.get(str(target.get('url') or '')) or {}
    fresh = 1 if int(st.get('finds') or 0) > 0 else 0
    ran_today = 1 if str(st.get('day') or '') == day else 0
    return (-fresh, ran_today, str(st.get('last_run') or ''))


def order_targets(targets: list, state: dict, day: str, limit: int) -> list:
    """Отбирает цели на проход в порядке приоритета (не больше limit)."""
    ordered = sorted(targets, key=lambda t: target_sort_key(t, state, day))
    if limit and limit > 0:
        return ordered[:limit]
    return ordered


def run_once(cfg: dict) -> int:
    """Один проход сбора: цели → страницы → отправка.

    Главное здесь — порядок работы. Обработка результата (отправка, запрос
    описаний, пауза) выполняется для КАЖДОЙ страницы ВНУТРИ цикла, а не
    после него. Раньше блок стоял снаружи: при цели на несколько страниц
    отправлялась только последняя, а `items` «протекало» между целями —
    при ошибке загрузки следующей цели на сервер уходили карточки
    ПРЕДЫДУЩЕЙ (или ничего, если переменная ещё не создана).

    Ошибка загрузки страницы (URLError / TimeoutError) — просто переход к
    следующей странице: состояние по цели не портится.
    """
    server, token = cfg['server'], cfg['token']
    total_sent = 0
    targets = list(cfg.get('targets', []))
    if not targets:
        # На сервере config.json нет — иначе сборщик шёл бы в пустоту
        targets = default_targets()
        print(f"Цели не заданы — берём встроенный список: {len(targets)} категорий по всей России")
    from_crit = targets_from_criteria(server, token, cfg)
    if from_crit:
        # Есть критерии пользователей — идём ТОЛЬКО по ним. Общие разделы
        # приносили в базу случайные товары (аудио, планшеты), и они попадали
        # в ленту как находки по чужому критерию.
        targets = list(from_crit)
        print(f"Цели: только критерии ({len(targets)}), общие разделы отключены")

    # Ограничение и ротация: за проход обходим не больше MAX_TARGETS целей,
    # в первую очередь те, что дают находки. Полный список не теряется —
    # остальные попадут в следующий проход.
    day = _today()
    state = load_targets_state()
    # По умолчанию одна цель за проход: страница Авито весит ~3,5 МБ, а
    # лимиты площадки срабатывают уже на втором запросе подряд.
    limit = int(cfg.get('max_targets') or 1)
    # Не долбим одну и ту же страницу: цель, которую проверяли недавно,
    # уступает место другим. Так каждый поиск проверяется по кругу, а не
    # каждые несколько минут.
    try:
        _min_interval = int(cfg.get('check_interval_min') or CHECK_INTERVAL_MIN)
    except Exception:
        _min_interval = CHECK_INTERVAL_MIN
    if _min_interval > 0:
        now_ts = time.time()
        fresh_enough = []
        for t in targets:
            st = state.get(str(t.get('url') or '')) or {}
            last = str(st.get('last_run') or '')
            if not last:
                fresh_enough.append(t)
                continue
            try:
                last_ts = time.mktime(time.strptime(last[:19], '%Y-%m-%dT%H:%M:%S'))
            except Exception:
                fresh_enough.append(t)
                continue
            if (now_ts - last_ts) >= _min_interval * 60:
                fresh_enough.append(t)
        if fresh_enough:
            targets = fresh_enough

    picked = order_targets(targets, state, day, limit)
    picked_urls = {str(t.get('url') or '') for t in picked}
    n_today = 0
    for t in targets:
        u = str(t.get('url') or '')
        if u in picked_urls or str((state.get(u) or {}).get('day') or '') == day:
            n_today += 1
    print(f"целей сегодня {n_today} из {len(targets)}")

    # Блок на ОДНОЙ странице не должен обрывать весь проход: Авито может
    # отдать 439 на конкретном URL (узкий подраздел, поиск по тексту) и при
    # этом спокойно отдать соседний раздел. Раньше первый же блок убивал
    # проход целиком, и сбор часами не работал.
    blocked_streak = 0
    # Раз в 5 проходов «прогреваемся» — как человек, который сначала
    # заходит на сайт, а потом в раздел.
    try:
        if int(cfg.get('warm_up_every') or WARM_UP_EVERY) > 0:
            _pn = int(os.environ.get('POLKA_PASS_N', '0') or 0)
            # Прогреваемся перед КАЖДЫМ проходом: главная открывается почти
            # всегда и даёт cookies, с которыми раздел отдаётся чаще.
            if _pn % int(cfg.get('warm_up_every') or WARM_UP_EVERY) == 0 or _BLOCK_BACKOFF[0] > 0:
                warm_up()
    except Exception:
        pass

    first_target = [True]
    for target in picked:
        # Между целями — пауза: два запроса подряд с одного IP Авито
        # воспринимает как бота и отвечает 429/439.
        if not first_target[0]:
            try:
                import random as _rnd
                _pause = int(cfg.get('target_pause') or TARGET_PAUSE)
                # После блокировки пауза длиннее: два запроса подряд по
                # разным разделам Авито считает серией и банит сильнее.
                if _BLOCK_BACKOFF[0]:
                    _pause = max(_pause, MIN_REQUEST_GAP) + _BLOCK_BACKOFF[0] * 30
                time.sleep(_pause + _rnd.randint(0, 5))
                print(f'  пауза {_pause} с перед следующим разделом')
            except Exception:
                pass
        first_target[0] = False
        source = target.get('source', 'avito')
        city = target.get('city', '')
        tkey = str(target.get('url') or '')
        finds_here = 0
        for url in target_urls(target, cfg):
            # Своё состояние на каждую страницу: чужие карточки сюда не
            # попадут ни при ошибке загрузки, ни при пустом разборе.
            items = []
            _tried_plain = False
            print(f"\n→ {source}: {url}")
            try:
                html = fetch(url, prefer_scraper=('q=' in url))
            except Blocked as exc:
                # Поиск по словам Авито отдаёт неохотно. Прежде чем уходить,
                # пробуем ту же страницу без q=: раздел отдаётся чаще, а слова
                # критерия отсеиваются уже на сервере.
                html = None
                if 'q=' in url and not _tried_plain:
                    _tried_plain = True
                    # Пересобираем адрес нормально: вырезание регуляркой
                    # оставляло «?» потерянным, и получался невалидный
                    # «/all/…&s=104» вместо «/all/…?s=104».
                    try:
                        from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
                        sp = urlsplit(url)
                        keep = [(k, v) for k, v in parse_qsl(sp.query, keep_blank_values=True)
                                if k != 'q']
                        plain = urlunsplit((sp.scheme, sp.netloc, sp.path,
                                            urlencode(keep), ''))
                    except Exception:
                        plain = re.sub(r'[?&]q=[^&]*', '', url)
                        plain = plain.replace('?&', '?').replace('&&', '&').rstrip('?&')
                    print(f"  ↻ поиск с q= закрыт — пробую раздел без q: {plain[:70]}")
                    try:
                        html = fetch(plain, prefer_scraper=False)
                        print("  ✓ раздел без q отдан")
                    except Exception as exc2:
                        print(f"  ⛔ {str(exc2)[:80]}")
                if html is None:
                    blocked_streak += 1
                    # Собираем, что успели: отправка идёт постранично.
                    save_targets_state(state)
                    print(f"  ⛔ {exc} — пропускаю страницу (блок {blocked_streak})")
                    if blocked_streak >= 2:
                        # Два блока подряд: отдыхаем и продолжаем сами.
                        # Раньше цикл завершался и стоял до ручного запуска.
                        block_cool_down()
                        blocked_streak = 0
                    continue
            except (urllib.error.URLError, TimeoutError) as exc:
                # Сеть отвалилась на этой странице — идём к следующей.
                # items остаётся пустым: к предыдущей цели не обращаемся.
                print(f"  ✖ не открылось: {exc}")
                continue
            items = parse_page(html)
            # Страница без единой карточки — это не «пустая выдача», а
            # антибот-заглушка: Авито так отвечает на частые запросы.
            # Раньше такой проход считался успешным, и мы тратили трафик
            # вхолостую. Теперь уходим на паузу.
            if not items and 'data-marker="item"' not in (html or ''):
                blocked_streak += 1
                _BLOCK_BACKOFF[0] = min(10, _BLOCK_BACKOFF[0] + 1)
                print(f"  ⛔ страница без объявлений — считаю блоком ({blocked_streak})")
                if blocked_streak >= 2:
                    save_targets_state(state)
                    block_cool_down()
                    blocked_streak = 0
                continue
            blocked_streak = 0
            _BLOCK_BACKOFF[0] = 0
            first_page_dated = date_sorted_first_page(url)
            for item in items:
                item['category'] = item.get('category') or target.get('category', '')
                item['city'] = item.get('city') or city
                # Этап D5: даты в карточке нет, но выдача отсортирована по
                # дате и это её первая страница — объявление почти наверняка
                # свежее, о чём и сообщаем серверу
                if item.get('hours_ago') is None and first_page_dated:
                    item['age_estimated'] = True
            # Фильтры из ссылки: цена и модель. Авито отдаёт обычный раздел,
            # поэтому отбираем сами — иначе в ленту попадёт вся категория.
            locals_here = target.get('local') or []
            if locals_here:
                before = len(items)
                items = [it for it in items
                         if any(matches_local(it, f) for f in locals_here)]
                if before != len(items):
                    print(f"  после фильтров ссылки: {len(items)} из {before}")
            print(f"  найдено карточек: {len(items)}")
            if not items:
                if '?' in url and 'q=' in url:
                    # Проверено на живом сайте: на поисковый запрос Авито отдаёт
                    # HTTP 200, но страницу БЕЗ объявлений — только подвал.
                    # Это не поломка разбора, а защита именно поиска.
                    print("  ⚠ Авито отдал пустую страницу: он не любит поиск по запросу (?q=).")
                    print("    Ссылки на КАТЕГОРИИ работают. Возьмите нужную категорию")
                    print("    на сайте, скопируйте адрес и добавьте в config.json:")
                    print('      {"source":"avito","url":"https://www.avito.ru/izhevsk/telefony",'
                          '"city":"Ижевск","category":"Электроника"}')
                else:
                    print("  ⚠ разбор ничего не дал — возможно, изменилась вёрстка сайта")
                continue
            try:
                stats = push(server, token, source, items)
                print(f"  отправлено: принято {stats.get('accepted')}, "
                      f"дублей {stats.get('duplicate')}, пропущено {stats.get('skipped')}")
                total_sent += int(stats.get('accepted') or 0)
                finds_here += int(stats.get('accepted') or 0)
                # Сервер отвечает, по каким карточкам нужно описание: отбор
                # по требованиям словами без него работает вслепую (этап A3)
                need = stats.get('need_details') or []
                details_left = int(cfg.get('details_per_pass') or DETAILS_PER_PASS)
                if need and details_left > 0:
                    _slice = need[:details_left]
                    print(f"  карточек на разбор: {len(_slice)} из {len(need)}")
                    collect_details(server, token, source, _slice)
            except Exception as exc:
                print(f"  ✖ сервер не принял: {exc}")
            # Пауза подлиннее: Авито ограничивает при частых запросах, а лишний
            # 429 обходится дороже, чем несколько секунд ожидания
            time.sleep(random.uniform(6.0, 12.0))

        # Итог по цели — в состояние ротации: сколько находок и когда бегали
        st = dict(state.get(tkey) or {})
        st['last_run'] = time.strftime('%Y-%m-%dT%H:%M:%S')
        st['day'] = day
        st['finds'] = finds_here
        st['runs'] = int(st.get('runs') or 0) + 1
        if tkey:
            state[tkey] = st

    save_targets_state(state)
    return total_sent


def fetch_need_details(server: str, token: str, limit: int = 0) -> list:
    """Спрашивает у сервера, какие карточки открыть ради описания."""
    url = f"{server.rstrip('/')}/api/ingest/need-details"
    if limit:
        url += f"?limit={int(limit)}"
    data = fetch_json(url, token)
    return data.get('items') or []


def details_only_loop(server: str, token: str, limit: int = 0,
                      loop: bool = False, every: int = 600) -> int:
    """Режим для домашнего IP: приносим ТОЛЬКО описания и продавца.

    Зачем отдельно: выдача собирается из облака (GitHub Actions) и с любого
    IP, а страницы объявлений Авито отдаёт только домашним адресам. Если
    телефон будет делать полный проход, он потратит домашний IP на то, что
    уже делает облако, и оба будут мешать друг другу. Здесь он берёт ровно
    те карточки, где описание влияет на отбор.

    Паузы щедрые (5–11 с между карточками): один и тот же домашний IP
    используется и вами, когда вы листаете Авито с телефона.
    """
    total = 0
    while True:
        # Не больше 8 карточек за проход: 30 подряд гарантированно дают 439.
        _limit = limit or 8
        try:
            items = fetch_need_details(server, token, _limit)
        except Exception as exc:
            print(f"  ✖ очередь не получена: {str(exc)[:120]}")
            items = []
        print(f"  карточек к открытию: {len(items)}")
        if items:
            try:
                # Пауза 20-40 с: на 5-11 с Авито отвечал 439 после третьей
                # карточки. Описания — единственный способ проверить слова,
                # которых нет в заголовке, поэтому лучше медленно, но да.
                got = collect_details(server, token, 'avito', items,
                                      pause=(20.0, 40.0))
                total += int(got or 0)
                print(f"  принесено описаний: {got} (всего за смену {total})")
            except Exception as exc:
                print(f"  ✖ описания не ушли: {str(exc)[:120]}")
        if _DETAILS_BLOCKED:
            print("  ⚠ Авито не пускает на страницы объявлений с этого IP.")
            print("    Проверьте: python3 collect.py --check-proxy")
        if not loop:
            return total
        # Ждём до следующего опроса ОЧЕРЕДИ (это наш сервер, Авито не
        # тревожим). Раньше здесь стоял минимум 120 секунд: объявление,
        # пришедшее сразу после прохода, ждало до двух минут. Теперь опрос
        # частый — карточка берётся в работу почти сразу. Темп по Авито при
        # этом не растёт: он задаётся числом карточек за проход и паузой
        # между ними, а не частотой опроса.
        wait = max(15, int(every)) + random.uniform(0, 10)
        print(f"  пауза {int(wait)} с…")
        time.sleep(wait)


def selftest() -> int:
    """Проверка разбора на образцах — без обращения к чужим сайтам.

    Две части: страница ВЫДАЧИ (fixture_avito.html) и страницы ОБЪЯВЛЕНИЙ
    (fixture_item_*.html: частник и магазин). Вторые нужны именно для
    parse_item_page: на живом сайте их проверять нельзя, а описание и
    продавец — то, ради чего этап A и делается.
    """
    here = os.path.dirname(os.path.abspath(__file__))

    listing_path = os.path.join(here, 'fixture_avito.html')
    with open(listing_path, encoding='utf-8') as fh:
        html = fh.read()
    items = parse_page(html)
    print(f"Разобрано карточек: {len(items)}")
    for item in items:
        print(f"  {item['title'][:40]:42} {item['price']:>9} ₽  id={item['external_id']}  "
              f"фото={len(item['photos'])}")
    ok = len(items) >= 2 and all(i['price'] > 0 and i['url'].startswith('http') for i in items)

    print()
    item_files = sorted(glob.glob(os.path.join(here, 'fixture_item*.html')))
    if not item_files:
        print("⚠ нет файлов fixture_item*.html — разбор страницы объявления не проверить")
    for path in item_files:
        with open(path, encoding='utf-8') as fh:
            page = fh.read()
        data = parse_item_page(page)
        kind = 'магазин' if data['seller_type'] == 'company' else (
            'частник' if data['seller_type'] == 'private' else 'тип не определён')
        print(f"  {os.path.basename(path):34} описание {len(data['description']):>4} симв. | "
              f"{kind} | {data['seller_name'][:34]!r} | объявлений: {data['seller_ads']}")
        print(f"      «{data['description'][:70].replace(chr(10), ' ')}…»")
        part_ok = (len(data['description']) >= 20
                   and data['seller_type'] in ('private', 'company'))
        if not part_ok:
            print("      ✖ описание или продавец не распознались")
        ok = ok and part_ok

    print("\nИТОГ:", "разбор работает" if ok else "РАЗБОР СЛОМАН")
    return 0 if ok else 1


def check_url(url: str) -> int:
    """Проверяет ЛЮБУЮ ссылку Авито: открывается ли и сколько карточек разобралось.

    Зачем: фильтры Авито (только частные, состояние, доставка, память) живут в
    самой ссылке. Форму этой ссылки знает только браузер — скопируйте адрес из
    строки браузера с нужными фильтрами и покажите его здесь. Если страница
    открывается и карточки разбираются, эту ссылку можно смело ставить
    сборщику как источник: фильтры будет применять сам Авито.
    """
    url = str(url or '').strip()
    if not url.startswith('http'):
        print("Укажите полную ссылку: --check-url \"https://www.avito.ru/...\"")
        return 2
    print(f"Проверяю: {url}")
    try:
        html = fetch(url, timeout=45, prefer_scraper=('q=' in url))
    except Exception as exc:
        print(f"  ✖ не открылась: {str(exc)[:140]}")
        print("    Если это 429/439 — Авито отбил запрос: подождите 10–15 минут")
        print("    и повторите (частые проверки он считает поведением бота).")
        return 1
    items = parse_page(html)
    print(f"  страница открылась, символов {len(html)}, карточек разобрано: {len(items)}")
    if not items:
        print("  ⚠ карточек нет: возможно, в ссылке ноль объявлений или другая вёрстка")
        return 1
    sellers = {}
    for it in items:
        st = it.get('seller_type') or 'не определён'
        sellers[st] = sellers.get(st, 0) + 1
    for it in items[:5]:
        print(f"    {str(it.get('title'))[:46]:48} {it.get('price')} ₽  "
              f"{it.get('city') or ''}  продавец: {it.get('seller_type') or '—'}")
    print(f"  типы продавца в выдаче: {sellers}")
    print("  ✅ ссылку можно использовать как источник для сборщика")
    return 0


def check_query(text: str) -> int:
    """Сравнивает две ссылки поиска на живом Авито: без q и с q.

    Нужна, чтобы убедиться, что Авито принимает текст запроса: одна точная
    выдача вместо перебора всей категории. Запускать со своего компьютера —
    у сервера может не быть доступа или он уже получил 429.
    """
    text = " ".join(str(text or '').split())
    if not text:
        print("Укажите текст: --check-query \"iphone 13 pro\"")
        return 2
    words = [w for w in text.lower().split() if w]
    slug = None
    for w in words:
        clean = w.strip('.,!?()"\'')
        if clean in CATEGORY_BY_WORD:
            slug = CATEGORY_BY_WORD[clean]
            break
    base = f"https://www.avito.ru/all/{slug}" if slug else "https://www.avito.ru/all"
    variants = [("без q (как было)", f"{base}?s=104"),
                ("с q (как стало)", f"{base}?s=104&q=" + quote_plus(text))]
    for title, url in variants:
        print(f"\n{title}: {url}")
        try:
            html = fetch(url, timeout=45, prefer_scraper=('q=' in url))
        except Exception as exc:
            print(f"  ✖ не получилось: {str(exc)[:120]}")
            time.sleep(random.uniform(4.0, 7.0))
            continue
        items = parse_page(html)
        rel = [it for it in items
               if all(w in (it.get('title') or '').lower() for w in words)]
        print(f"  карточек {len(items)}, из них по словам {words}: {len(rel)}")
        for it in rel[:4]:
            print(f"     {it.get('title')} — {it.get('price')} ₽")
        time.sleep(random.uniform(4.0, 7.0))
    print("\nЕсли «с q» даёт заметно больше подходящих — формат верный, "
          "сборщик уже так и работает. Если Авито не понял q, запустите "
          "сборщик с POLKA_SEARCH_BY_QUERY=0 (вернётся прежнее поведение).")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Сборщик находок для «Полки»")
    ap.add_argument('--config', default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                     'config.json'))
    ap.add_argument('--selftest', action='store_true', help='проверить разбор на образце')
    ap.add_argument('--check-proxy', metavar='URL', nargs='?', const='DEF',
                    help='проверить, пускает ли Авито через прокси')
    ap.add_argument('--check', action='store_true',
                    help='перепроверить лоты: продано или ещё висит')
    ap.add_argument('--check-url', metavar='ССЫЛКА',
                    help='проверить ссылку Авито с фильтрами из браузера')
    ap.add_argument('--check-query', metavar='ТЕКСТ',
                    help='сравнить поиск по тексту запроса и по категории')
    ap.add_argument('--details-only', metavar='N', nargs='?', const='0',
                    help='только описания: открывать N карточек за проход '
                         '(режим для домашнего IP — телефон, ноутбук, малина)')
    ap.add_argument('--loop', action='store_true', help='работать постоянно')
    ap.add_argument('--every', type=int, default=900, help='пауза между проходами, сек')
    args = ap.parse_args()

    if args.selftest:
        return selftest()

    if args.check_url:
        return check_url(args.check_url)

    if args.check_query is not None:
        return check_query(args.check_query)

    # Режим «только описания»: сервер и токен берём из config.json,
    # цели и выдача тут не нужны вовсе
    if args.details_only is not None:
        cfg_d = load_config(args.config)
        try:
            limit_d = int(args.details_only or 0)
        except ValueError:
            limit_d = 0
        server_d = os.environ.get('POLKA_SERVER') or cfg_d['server']
        token_d = os.environ.get('POLKA_INGEST_TOKEN') or cfg_d['token']
        mode = 'постоянно' if args.loop else 'один проход'
        print(f"Режим «только описания» ({mode}), по {limit_d or 'HUNT_DESC_PER_PASS'} карточек")
        return details_only_loop(server_d, token_d, limit=limit_d,
                                 loop=bool(args.loop),
                                 every=max(120, int(args.every)))

    # Проверка прокси — отдельная диагностика: сервер и токен тут не нужны,
    # иначе проверить прокси до покупки было бы невозможно
    if args.check_proxy is not None:
        target = args.check_proxy
        if target in ('DEF', ''):
            target = "https://www.avito.ru/izhevsk/velosipedy"
        return check_proxy(target)

    cfg = load_config(args.config)
    # Режим сервера: цели только из критериев пользователей, файл не нужен
    if os.environ.get('POLKA_SERVER_MODE') == '1':
        args.loop = True if args.loop is None else args.loop

    if args.check:
        print("Проверяем, что уже продано…")
        check_listings(cfg['server'], cfg['token'], limit=args.every if False else 30)
        return 0

    while True:
        started = time.time()
        try:
            sent = run_once(cfg)
        except SystemExit as exc:
            if exc.code == 3:
                print("Нас заблокировали. Ждём долго, чтобы не закрепить блокировку.")
                raise
            raise
        print(f"\nПроход завершён, принято новых: {sent}")
        # Раз в проход смотрим, что уже ушло — так копится статистика
        # «за сколько часов уходит такая цена»
        check_listings(cfg['server'], cfg['token'], limit=25)
        if not args.loop:
            return 0
        wait = max(30, args.every - int(time.time() - started))
        print(f"Следующий проход через {wait} с")
        time.sleep(wait)


if __name__ == '__main__':
    sys.exit(main())
